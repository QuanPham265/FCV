CREATE MATERIALIZED VIEW sub_vwpsoutletprofile AS WITH vw_perfect_store_usermanager AS (
         SELECT DISTINCT ON (vw_sub_perfect_store_usermanager.nnwid, vw_sub_perfect_store_usermanager.rsmid, vw_sub_perfect_store_usermanager.regionid, vw_sub_perfect_store_usermanager.asmid, vw_sub_perfect_store_usermanager.cityid, vw_sub_perfect_store_usermanager.seid, vw_sub_perfect_store_usermanager.distributorid) vw_sub_perfect_store_usermanager.nnwid,
            vw_sub_perfect_store_usermanager.nnw_username,
            vw_sub_perfect_store_usermanager.nnw_fullname,
            vw_sub_perfect_store_usermanager.rsmid,
            vw_sub_perfect_store_usermanager.rsm_username,
            vw_sub_perfect_store_usermanager.rsm_fullname,
            vw_sub_perfect_store_usermanager.regionid,
            vw_sub_perfect_store_usermanager.regionname,
            vw_sub_perfect_store_usermanager.asmid,
            vw_sub_perfect_store_usermanager.asm_username,
            vw_sub_perfect_store_usermanager.asm_fullname,
            vw_sub_perfect_store_usermanager.cityid,
            vw_sub_perfect_store_usermanager.cityname,
            vw_sub_perfect_store_usermanager.seid,
            vw_sub_perfect_store_usermanager.se_username,
            vw_sub_perfect_store_usermanager.se_fullname,
            vw_sub_perfect_store_usermanager.distributorid,
            vw_sub_perfect_store_usermanager.distributorcode,
            vw_sub_perfect_store_usermanager.distributorname,
            vw_sub_perfect_store_usermanager.smid,
            vw_sub_perfect_store_usermanager.sm_username,
            vw_sub_perfect_store_usermanager.sm_fullname,
            vw_sub_perfect_store_usermanager.located
           FROM fcvplatform.vw_sub_perfect_store_usermanager
        )
 SELECT psoutlet.name AS psoutletname,
    psoutlet.street AS psoutletstreet,
    psoutlet.locationno AS psoutletlocationno,
    psoutlet.phonenumber AS psoutletphonenumber,
    psoutlet.email AS psoutletemail,
    psoutlet.idno AS psoutletidno,
    psoutlet.bankaccount AS psoutletbankaccount,
    u.distributorcode,
    u.distributorname,
    u.regionname,
    ''::text AS statename,
    psoutlet.code AS psoutletcode,
    psoutlet.ward AS psoutletward,
    u.cityname,
    psoutlet.district AS psoutletdistrict,
    psoutlet.bankaccountaddress,
    psoutlet.bankaccountname,
    psoutlet.outletid AS psoutletid,
    psoutlet.fullname,
    lm.description,
    users.fullname AS sm_fullname,
    users.username AS sm_username,
    users.userid AS smid,
    u.se_fullname,
    u.se_username,
    u.seid,
    u.asm_fullname,
    u.asm_username,
    u.asmid,
    u.rsm_fullname,
    u.rsm_username,
    u.rsmid,
    psoutlet.dmsoutletid,
    u.distributorid,
    u.cityid,
    u.regionid,
    lm.outletid,
    u.nnwid,
    u.located
   FROM (((fcvplatform.psoutlet psoutlet
     LEFT JOIN fcvplatform.linemanager lm ON ((lm.outletid = psoutlet.dmsoutletid)))
     LEFT JOIN fcvplatform.users users ON ((users.userid = lm.userid)))
     JOIN vw_perfect_store_usermanager u ON ((u.distributorid = psoutlet.sub_distributorid)))
  WHERE ((psoutlet.status = 1) AND ((psoutlet.statusmerge IS NULL) OR (psoutlet.statusmerge = false)) AND (EXISTS ( SELECT 1
           FROM fcvplatform.linemanager lm1
          WHERE ((lm1.userid = u.seid) AND ((lm.userid IS NULL) OR (lm1.staffuserid = lm.userid))))));
CREATE INDEX in_outletid_sub_vwpsoutletprofile
  ON sub_vwpsoutletprofile (psoutletid);
CREATE INDEX in_seid_sub_vwpsoutletprofile
  ON sub_vwpsoutletprofile (seid);
CREATE INDEX in_dmsoutletid_sub_vwpsoutletprofile
  ON sub_vwpsoutletprofile (dmsoutletid);
CREATE INDEX in_distributorid_sub_vwpsoutletprofile
  ON sub_vwpsoutletprofile (distributorid);
CREATE INDEX in_regionid_sub_vwpsoutletprofile
  ON sub_vwpsoutletprofile (regionid);
