create function update3psbudgettargetsdistributor(monthvar integer, yearvar integer, distributoridvar bigint[]) returns void
LANGUAGE plpgsql
AS $$
DECLARE statusDefault CONSTANT integer := 100;
        monthNextVar integer := monthvar + 1;
        yearNextVar integer := yearvar;
BEGIN
  IF monthvar = 12 THEN
    monthNextVar := 1;
    yearNextVar := yearvar + 1;
  END IF;

  -- clear data in 3 table target
  DELETE FROM fcvplatform.psbudgettargetsdistributor td WHERE td.month = monthNextVar and td.year = yearNextVar and td.distributorid = ANY (distributorIdVar);
  DELETE FROM fcvplatform.psbudgettargetsdistributordetail tdd WHERE NOT EXISTS(SELECT * FROM fcvplatform.psbudgettargetsdistributor td WHERE td.psbudgettargetsdistributorid = tdd.psbudgettargetsdistributorid);
  DELETE FROM fcvplatform.psbudgettargetsdistributorcatgroupdetail tdc WHERE NOT EXISTS(SELECT * FROM fcvplatform.psbudgettargetsdistributor td WHERE td.psbudgettargetsdistributorid = tdc.psbudgettargetsdistributorid);

  -- Function sync data for table 'psBudgetTargetsDistributor'
  INSERT INTO fcvplatform.psbudgettargetsdistributor (seid, asmid, distributorid, month, year, type)
    SELECT v.seid, v.asmid, alog.distributorid, monthNextVar, yearNextVar, 1
    FROM fcvplatform.distributorapprovedlog alog
      INNER JOIN fcvplatform.vw_sub_perfect_store_usermanager v ON v.distributorid = alog.distributorid
    WHERE alog.month = monthVar and alog.year = yearVar and alog.distributorid = ANY (distributorIdVar) and alog.status = statusDefault
    GROUP BY v.seid, v.asmid, alog.distributorid, alog.month, alog.year;

  -- Function sync data for table 'psBudgetTargetsDistributorDetail'
  WITH psoutletRegisterTableTmp AS (
      SELECT p.sub_distributorid, rd.outletmodelgroupid, rd.outletmodelid, count(r.outletid) totalOulet, sum(rd.displaycost) displaycostTotal, sum(rd.locationcost) locationcostTotal, (rd.cashier is null) isCashier
      FROM fcvplatform.psoutlet p
        INNER JOIN fcvplatform.psoutletmonthlyregister r ON p.outletid = r.outletid
        INNER JOIN fcvplatform.psoutletmonthlyregisterdetail rd ON r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
      WHERE r.month = monthVar AND r.year = yearVar AND r.status = statusDefault AND  p.sub_distributorid = ANY (distributorIdVar)
      GROUP BY p.sub_distributorid, rd.outletmodelgroupid, rd.outletmodelid, rd.cashier
  )
  INSERT INTO fcvplatform.psbudgettargetsdistributordetail (psbudgettargetsdistributorid, outletmodelgroupid, outletmodelid, totaloutlet, displaycost, locationcost, iscashier)
    SELECT td.psbudgettargetsdistributorid, ro.outletmodelgroupid, ro.outletmodelid, sum(ro.totalOulet), sum(ro.displaycostTotal), sum(ro.locationcostTotal), ro.isCashier
    FROM fcvplatform.psbudgettargetsdistributor td
      INNER JOIN psoutletRegisterTableTmp ro ON ro.sub_distributorid = td.distributorid
    GROUP BY psbudgettargetsdistributorid, ro.outletmodelgroupid, ro.outletmodelid, ro.isCashier;

  -- Function sync data for table 'psBudgetTargetsDistributorCatGroupDetail'
  WITH psoutletRegisterTableTmp AS (
      SELECT p.sub_distributorid, om.catgroupid, count(r.outletid) totalOulet, sum(rd.displaycost) displaycostTotal, sum(rd.locationcost) locationcostTotal
      FROM fcvplatform.psoutlet p
        INNER JOIN fcvplatform.psoutletmonthlyregister r ON p.outletid = r.outletid
        INNER JOIN fcvplatform.psoutletmonthlyregisterdetail rd ON r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
        INNER JOIN fcvplatform.outletmodel om ON rd.outletmodelid = om.outletmodelid
      where r.month = monthVar and r.year = yearVar and r.status = statusDefault and  p.sub_distributorid = ANY (distributorIdVar)
      GROUP BY p.sub_distributorid, om.catgroupid
  )
  INSERT INTO fcvplatform.psbudgettargetsdistributorcatgroupdetail (psbudgettargetsdistributorid, catgroupid, totaloutlet, displaycost, locationcost)
    SELECT td.psbudgettargetsdistributorid, ro.catgroupid, sum(ro.totalOulet), sum(ro.displaycostTotal), sum(ro.locationcostTotal)
    FROM fcvplatform.psbudgettargetsdistributor td
      INNER JOIN psoutletRegisterTableTmp ro ON ro.sub_distributorid = td.distributorid
    GROUP BY td.psbudgettargetsdistributorid, ro.catgroupid;
END;
$$;
