create function fn_adduserrolebygroup(usergroupcode text, rolecode text) returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN SELECT userid, (select roleid FROM role WHERE role.code = roleCode) FROM users WHERE usergroupid = (select usergroupid from usergroup WHERE usergroup.code = userGroupCode) LOOP
    BEGIN
      INSERT INTO userroleacl (userid,roleid,createddate)
      VALUES (rec.userid,rec.roleid,now());
    END;
  END LOOP;
END;
$$;
