create function fn_summary_partial_register_all(distributorids bigint[], p_month integer, p_year integer, statusapprove integer[]) returns integer
LANGUAGE plpgsql
AS $$
declare monthYear_rc record;
  declare disId bigint;
BEGIN
  IF (distributorIds IS NULL) THEN
    distributorIds := array(select distributorid from fcvplatform.subdistributor where isgtdc = true and record_del = false);
  END IF;

  CREATE TEMP TABLE monthYear_list
  (
    month integer,
    year integer
  )
  ON COMMIT DROP;

  IF(p_month IS NULL AND p_year IS NULL) THEN
    INSERT into monthYear_list(month, year) select distinct on(r.month, r.year) r.month, r.year from fcvplatform.psoutletmonthlyregisterpartial r;
  END IF;

  IF(array_length(distributorIds, 1) > 0) THEN
    FOREACH disId in ARRAY distributorIds
    LOOP
      BEGIN
        IF(p_month IS NULL AND p_year IS NULL) THEN
          FOR monthYear_rc in select * from monthYear_list
          LOOP
            BEGIN
              PERFORM * from fcvplatform.fn_summary_partial_register(disId, monthYear_rc.month, monthYear_rc.year, statusapprove);
            END;
          END LOOP;
        ELSE
          PERFORM * from fcvplatform.fn_summary_partial_register(disId, p_month, p_year, statusapprove);
        END IF;
      END;
    END LOOP;
  END IF;

  return 1;
END;
$$;
