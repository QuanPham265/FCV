create function fn_updatetotalcostdmsinvoice() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec RECORD;
BEGIN
  FOR rec IN
  SELECT
    dd.invoiceId,
    sum(cost) AS costPosm
  FROM fcvplatform.dmsinvoicedetail AS dd
    INNER JOIN dmsinvoice as d on dd.invoiceid = d.invoiceid
  WHERE posm = TRUE and issueddate >= DATE('2017-10-01') and issueddate <= DATE('2017-10-31') and d.backuptotalcost is null
  GROUP BY dd.invoiceid
  HAVING Sum(cost) > 0
  LOOP
    BEGIN
      UPDATE dmsinvoice
      SET totalcost = totalcost - rec.costPosm, backuptotalcost = totalcost
      WHERE dmsinvoice.invoiceid = rec.invoiceid;
    END;
  END LOOP;
END;
$$;
