create function fn_inserttochangeinforequestdetail() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN

  select ci.changeinforequestid,ccd.field, ccd.oldvalue,ccd.newvalue, ccd.status from changeinforequest as ci
    INNER JOIN changeinforequestdetail as ccd on ci.mergefromid = ccd.changeinforequestid
  where mergefromid is not null
  LOOP
    BEGIN
      INSERT INTO changeinforequestdetail (
        changeinforequestid,
        field,
        oldvalue,
        newvalue,
        status
      ) VALUES (
        rec.changeinforequestid,
        rec.field,
        rec.oldvalue,
        rec.newvalue,
        rec.status
      );

    END;
  END LOOP;
END;
$$;
