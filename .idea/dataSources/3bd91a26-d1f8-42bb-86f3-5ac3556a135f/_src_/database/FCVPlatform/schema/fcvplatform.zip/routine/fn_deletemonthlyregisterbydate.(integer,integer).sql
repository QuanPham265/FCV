create function fn_deletemonthlyregisterbydate(monthvar integer, yearvar integer) returns void
LANGUAGE plpgsql
AS $$
BEGIN
  delete from fcvplatform.psoutletmonthlyregisterpartial where psoutletmonthlyregisterpartialid in (
    select psoutletmonthlyregisterpartialid from fcvplatform.psoutletmonthlyregisterdetailpartial
    where month = monthvar and year = yearvar
  );

  delete from fcvplatform.psoutletmonthlyregisterdetail_bk_final where psoutletmonthlyregisterid in (
    select psoutletmonthlyregisterid from fcvplatform.psoutletmonthlyregister_bk_final
    where month = monthvar and year = yearvar
  );

  delete from fcvplatform.psoutletmonthlyregisterdetailtemp where psoutletmonthlyregisterid in (
    select psoutletmonthlyregisterid from fcvplatform.psoutletmonthlyregistertemp
    where month = monthvar and year = yearvar
  );

  delete from fcvplatform.psoutletmonthlyregisterdetail where psoutletmonthlyregisterid in (
    select psoutletmonthlyregisterid from fcvplatform.psoutletmonthlyregister where month = monthvar and year = yearvar
  );
  delete from fcvplatform.psoutletmonthlyregister where month = monthvar AND year = yearvar;
  delete from fcvplatform.psoutletmonthlyregister_bk_final where month = monthvar and year = yearvar;
  delete from fcvplatform.psoutletmonthlyregistertemp where month = monthvar and year = yearvar;
  delete from fcvplatform.psoutletmonthlyregisterpartial where month = monthvar and year = yearvar;
  delete from fcvplatform.distributorapprovedlog where month = monthvar and year = yearvar;
  delete from fcvplatform.distributorregistrydetail where month = monthvar and year = yearvar;

END;
$$;
