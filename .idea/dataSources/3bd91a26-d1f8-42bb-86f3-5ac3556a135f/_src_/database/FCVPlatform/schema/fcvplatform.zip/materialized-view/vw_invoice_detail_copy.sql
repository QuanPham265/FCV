CREATE MATERIALIZED VIEW vw_invoice_detail_copy AS WITH dmsinvoiceids AS (
         WITH dmsoutletids AS (
                 SELECT dmsoutlet.dmsoutletid
                   FROM fcvplatform.dmsoutlet
                  WHERE ((dmsoutlet.code)::text IN ( SELECT mergecustomerlog.customeroldcode
                           FROM fcvplatform.mergecustomerlog
                          WHERE ((mergecustomerlog.status)::text = 'NEW'::text)))
                )
         SELECT dmsinvoice.invoiceid
           FROM fcvplatform.dmsinvoice
          WHERE (dmsinvoice.dmsoutletid = ANY (ARRAY( SELECT dmsoutletids.dmsoutletid
                   FROM dmsoutletids)))
        )
 SELECT id.invoicedetailid,
    id.invoiceid,
    id.productid,
    id.quantity,
    id.costperunit,
    id.cost,
    id.extendedamount,
    id.tax,
    id.exchangerate,
    id.description,
    id.versionnumber,
    id.idold,
    id.idhashcode,
    id.createddate,
    id.doc_type,
    id.cust_city,
    id.cust_province,
    id.geography,
    id.channel,
    id.outlet,
    id.key_acc,
    id.key_acc_region,
    id.prd_desc,
    id.mg1,
    id.mg2,
    id.mg3,
    id.mg4,
    id.prd_content,
    id.uom_cd,
    id.uom_listprice,
    id.promo_disc,
    id.net_amt,
    id.slsman_cd,
    id.slsman_name,
    id.reason_code,
    id.remark,
    id.inv_key,
    id.so_no,
    id.so_key,
    id.whs_cd,
    id.inv_ind,
    id.bill_to_cd,
    id.cust_type,
    id.so_dt,
    id.created_by,
    id.delivery_dt,
    id.invterm_cd,
    id.inv_status,
    id.gross_ttl,
    id.net_ttl,
    id.net_ttl_tax,
    id.adj_amt,
    id.taxable_amt,
    id.taxable_amt_foc,
    id.nontaxable_amt,
    id.tax_ttl,
    id.promo_disc_ttl,
    id.prd_index,
    id.tax_ind,
    id.def_uom_cd,
    id.prd_listprice,
    id.prd_disc,
    id.net_amt_tax,
    id.net_amt_foc,
    id.tax_perc,
    id.tax_amt,
    id.shipto_cd,
    id.shipto_desc,
    id.prd_cost_price,
    id.selling_type,
    id.invoice_due_dt,
    id.inv_no_assigned_cn,
    id.promo_cd,
    id.gps_latitude,
    id.gps_longitude,
    id.mergefromid,
    id.mergedate,
    id.parentcodeindicators,
    id.updatersoafter
   FROM fcvplatform.dmsinvoicedetail id
  WHERE (id.invoiceid = ANY (ARRAY( SELECT dmsinvoiceids.invoiceid
           FROM dmsinvoiceids)));
CREATE INDEX in_invoicedetailid_vw_invoice_detail_copy
  ON vw_invoice_detail_copy (invoicedetailid);
CREATE INDEX in_invoiceid_vw_invoice_detail_copy
  ON vw_invoice_detail_copy (invoiceid);
