create function fn_copy_registry_final_m_y(m_month integer, y_year integer, s_status integer) returns integer
LANGUAGE plpgsql
AS $$
declare d_distributorid record;
BEGIN

    BEGIN
	FOR d_distributorid IN (select distributorid from fcvplatform.subdistributor where record_del = false and isgtdc)
	LOOP
		BEGIN
			perform fcvplatform.fn_copy_registry_final(d_distributorid.distributorid, m_month, y_year, s_status);
		END;
	END LOOP;    
    END;
    return 1;
END;
$$;
