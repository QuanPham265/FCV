create function fn_archiveimportpoint(vardate character varying) returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN select * from loyaltypointupdate WHERE DATE(createddate) = to_date(varDate,'ddMMyyyy') LOOP
    BEGIN
      INSERT INTO loyaltypointupdate_archive (
        loyaltypointupdateid,
        bonuspointforrank,
        bonuspointnotforrank,
        distributorcode,
        errormessage,
        shopcode,
        statuscode,
        statecode,
        createddate,
        modifieddate,
        customerid,
        cycleid,
        idold,
        idhashcode,
        infoupdate,
        mergefromid,
        mergedate
      ) VALUES (
        rec.loyaltypointupdateid,
        rec.bonuspointforrank,
        rec.bonuspointnotforrank,
        rec.distributorcode,
        rec.errormessage,
        rec.shopcode,
        rec.statuscode,
        rec.statecode,
        rec.createddate,
        rec.modifieddate,
        rec.customerid,
        rec.cycleid,
        rec.idold,
        rec.idhashcode,
        rec.infoupdate,
        rec.mergefromid,
        rec.mergedate
      );
    END;
  END LOOP;
END;
$$;
