create function fn_findregistry_ff_chdd(outletids bigint[], m_month integer[], y_year integer, s_status integer[], p_perfectcode text[]) returns TABLE(outletid bigint, month integer, omid bigint, perfectcode text)
LANGUAGE plpgsql
AS $$
BEGIN
return QUERY 
select r.outletid, cast (r.month as integer),om.outletmodelid, cast (om.perfectcode as text)
from fcvplatform.psoutletmonthlyregister r
inner join fcvplatform.psoutletmonthlyregisterdetail rd
on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
inner join fcvplatform.outletmodel om 
on om.outletmodelid = rd.outletmodelid
where r.month = ANY(m_month) and r.year = y_year and r.status = ANY(s_status)
and (-1 = ANY(outletids) or r.outletid = ANY(outletids))
and om.perfectcode = ANY(p_perfectcode); 
END;
$$;
