create function refreshvsummarypointcycleofcustomerbymonth() returns integer
LANGUAGE plpgsql
AS $$
BEGIN
  EXECUTE 'REFRESH MATERIALIZED VIEW FCVPlatform.VSummaryPointCycleOfCustomerByMonth';

  RETURN 1;
END
$$;
