create function fn_copy_registry_final(d_distributorid bigint, m_month integer, y_year integer, s_status integer) returns integer
LANGUAGE plpgsql
AS $$
declare x record;
BEGIN

    BEGIN

	IF (select not exists (select 1 from fcvplatform.psoutletmonthlyregister_bk_final where month = m_month and year = y_year and status = s_status and distributorid = d_distributorid)) THEN

	      DELETE from fcvplatform.psoutletmonthlyregister_bk_final
	      where month = m_month and year = y_year and status = s_status and distributorid = d_distributorid;
	      
	      INSERT INTO fcvplatform.psoutletmonthlyregister_bk_final (
			outletid,
			month,
			year,
			status,
			createdby,
			createddate,
			modifiedby,
			modifieddate,
			statuslocationcost,
			statusgroupplan,
			typeplan,
			partialplan,
			partialstatus,
			reject_note,
			approval_note,
			isseapproved,
			isasmapproved,
			isrsmapproved,
			isnnwapproved,
			forceeditrejectouttime,
			distributorid,
			temp_r_id
	      )
	      (
	        select  r.outletid,
			r.month,
			r.year,
			r.status,
			r.createdby,
			r.createddate,
			r.modifiedby,
			r.modifieddate,
			r.statuslocationcost,
			r.statusgroupplan,
			r.typeplan,
			r.partialplan,
			r.partialstatus,
			r.reject_note,
			r.approval_note,
			r.isseapproved,
			r.isasmapproved,
			r.isrsmapproved,
			r.isnnwapproved,
			r.forceeditrejectouttime,
			d_distributorid,
			r.psoutletmonthlyregisterid
		from fcvplatform.psoutletmonthlyregistertemp r
		inner join fcvplatform.psoutlet p on p.outletid = r.outletid 
		where r.month = m_month and r.year = y_year and r.status = s_status and p.sub_distributorid = d_distributorid
	      );
	      INSERT INTO fcvplatform.psoutletmonthlyregisterdetail_bk_final (
			psoutletmonthlyregisterid,
			psoutletmodelsettingid,
			expectcutoff,
			commitcutoff,
			commitnote,
			displaycost,
			displaylocationid,
			locationcost,
			outletmodelgroupid,
			outletmodelid,
			outletmodeloldid,
			locationnote,
			model_note,
			partialplan,
			partialstatus,
			cashier
	      )
	      (
	        select  r.psoutletmonthlyregisterid,
			rd.psoutletmodelsettingid,
			rd.expectcutoff,
			rd.commitcutoff,
			rd.commitnote,
			rd.displaycost,
			rd.displaylocationid,
			rd.locationcost,
			rd.outletmodelgroupid,
			rd.outletmodelid,
			rd.outletmodeloldid,
			rd.locationnote,
			rd.model_note,
			rd.partialplan,
			rd.partialstatus,
			rd.cashier
		from fcvplatform.psoutletmonthlyregisterdetailtemp rd
		inner join fcvplatform.psoutletmonthlyregister_bk_final r on r.temp_r_id = rd.psoutletmonthlyregisterid
		where r.month = m_month and r.year = y_year and r.status = s_status and r.distributorid = d_distributorid
	      );
	END IF;
	    
    END;
    return 1;
END;
$$;
