create function pr_rejected_revert_data_list_distributor(userid bigint, d_distributorid bigint[], m_month integer, y_year integer, current_status integer[], next_status integer) returns integer
LANGUAGE plpgsql
AS $$
declare disId bigint;
  declare partial_rc record;
BEGIN
  IF (next_status = ANY(current_status)) THEN
    return -1;
  END IF;
  FOR disId IN (select distributorid from fcvplatform.subdistributor  where distributorid = ANY(d_distributorid))
  LOOP
    FOR partial_rc IN
    select r.outletid,
      r.month,
      r.year,
      r.status,
      r.createdby,
      r.createddate,
      r.modifiedby,
      r.modifieddate,
      r.actiontype,
      r.psoutletmonthlyregisterpartialid
    from fcvplatform.psoutletmonthlyregisterpartial r
      inner join fcvplatform.psoutlet p on p.outletid = r.outletid
    where r.month = m_month and r.year = y_year and r.status = ANY(current_status) and p.sub_distributorid = disId
    LOOP
      PERFORM * FROM fcvplatform.partial_register_rejected_revert_data(m_month, y_year, partial_rc.outletid, partial_rc.actiontype);
      PERFORM * FROM fcvplatform.partial_register_rejected_revert_data_temp(m_month, y_year, partial_rc.outletid, partial_rc.actiontype);

      UPDATE fcvplatform.psoutletmonthlyregisterpartial r
      SET status = next_status
      WHERE r.psoutletmonthlyregisterpartialid = partial_rc.psoutletmonthlyregisterpartialid;
    END LOOP;
  END LOOP;
  IF (100 = ANY(current_status)) THEN
    return 100;
  END IF;
  return 1;
END;
$$;
