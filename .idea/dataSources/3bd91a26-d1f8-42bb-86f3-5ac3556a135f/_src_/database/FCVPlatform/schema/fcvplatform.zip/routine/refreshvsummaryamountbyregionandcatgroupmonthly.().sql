create function refreshvsummaryamountbyregionandcatgroupmonthly() returns integer
LANGUAGE plpgsql
AS $$
BEGIN
    EXECUTE 'REFRESH MATERIALIZED VIEW FCVPlatform.VSummaryAmountByRegionAndCatgroupMonthly';

    RETURN 1;
END
$$;
