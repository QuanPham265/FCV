create function fn_findregistry_locationcost_m0_m1_by_outletids(o_outletids bigint[], month_m0 integer, year_m0 integer, status_m0 integer[]) returns TABLE(outletid bigint, m0_locationcost numeric, m1_locationcost numeric)
LANGUAGE plpgsql
AS $$
declare year_m1 integer;
declare month_m1 integer;
BEGIN
month_m1 = month_m0 - 1;
year_m1 = year_m0;
if (month_m0 = 1) then 
	month_m1 = 12;
	year_m1 = year_m0 - 1;
end if;

RETURN QUERY 
with rg_old as (
select  r.outletid,
	sum(COALESCE(rd.locationcost, 0)) locationcost
from fcvplatform.psoutletmonthlyregistertemp  r
inner join fcvplatform.psoutletmonthlyregisterdetailtemp rd
on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
where r.month = month_m1 and r.year = year_m1 and r.status = 100
and (-1 = ANY(o_outletids) or r.outletid = ANY (o_outletids))
group by r.outletid
)
select  rg_new.outletid,
	rg_new.locationcost m0_locationcost,
	rg_old.locationcost m1_locationcost
from (
select  r.outletid,
	sum(COALESCE(rd.locationcost, 0)) locationcost
from fcvplatform.psoutletmonthlyregistertemp  r
inner join fcvplatform.psoutletmonthlyregisterdetailtemp rd
on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
where r.month = month_m0 and r.year = year_m0  and (-1 = ANY (status_m0) or r.status = ANY (status_m0))
and (-1 = ANY(o_outletids) or r.outletid = ANY (o_outletids))
group by r.outletid
) rg_new
left join rg_old on rg_old.outletid = rg_new.outletid
where 1=1
and (rg_new.locationcost is not null and rg_new.locationcost > 0);

END;
$$;
