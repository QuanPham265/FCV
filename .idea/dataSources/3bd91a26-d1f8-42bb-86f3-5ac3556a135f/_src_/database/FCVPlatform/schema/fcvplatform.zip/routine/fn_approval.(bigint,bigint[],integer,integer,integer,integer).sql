create function fn_approval(userid bigint, d_distributorid bigint[], m_month integer, y_year integer, current_status integer, next_status integer) returns integer
LANGUAGE plpgsql
AS $$
declare disId bigint;
declare begin_rg_id bigint;
declare begin_rg_temp_id bigint;
declare begin_partial_id bigint;
declare partial_rc record;
declare partial_id_flag bigint;
BEGIN
   IF (current_status = next_status) THEN
	return -1;
   END IF;
   --begin_rg_id = 10 + select nextval('fcvplatform.psoutletmonthlyregister_psoutletmonthlyregisterid_seq');
   --begin_rg_temp_id = 10 + select nextval('fcvplatform.psoutletmonthlyregistertemp_psoutletmonthlyregisterid_seq');
   FOR disId IN (select distributorid from fcvplatform.subdistributor  where distributorid = ANY(d_distributorid))
   LOOP
	partial_id_flag = 0;
	FOR partial_rc IN
	with registry_need_update as (
		select  r.outletid,
			r.month,
			r.year,
			r.status,
			r.createdby,
			r.createddate,
			r.modifiedby,
			r.modifieddate,
			r.actiontype,
			rd.*,
			mr.psoutletmonthlyregisterid mr_id,
			mrt.psoutletmonthlyregisterid mrt_id
		from fcvplatform.psoutletmonthlyregisterpartial r
		inner join fcvplatform.psoutletmonthlyregisterdetailpartial rd
		on r.psoutletmonthlyregisterpartialid = rd.psoutletmonthlyregisterpartialid
		inner join fcvplatform.psoutlet p on p.outletid = r.outletid
		left join fcvplatform.psoutletmonthlyregister mr
		on (mr.outletid = r.outletid and mr.month = r.month and mr.year = r.year)
		left join fcvplatform.psoutletmonthlyregistertemp mrt
		on (mrt.outletid = r.outletid and mrt.month = r.month and mrt.year = r.year)
		where r.month = m_month and r.year = y_year and r.status = current_status
		and p.sub_distributorid = disId
	)
	select *
	from registry_need_update u
	LOOP
	    IF 	(next_status = 100) THEN
		IF (partial_id_flag != partial_rc.psoutletmonthlyregisterpartialid) THEN
			partial_id_flag = partial_rc.psoutletmonthlyregisterpartialid;
			IF (partial_rc.actiontype = 1000 or partial_rc.actiontype = 1001) THEN
				IF (partial_rc.mr_id is null) THEN
				select nextval('fcvplatform.psoutletmonthlyregister_psoutletmonthlyregisterid_seq') INTO begin_rg_id;
				INSERT INTO fcvplatform.psoutletmonthlyregister
				(
					psoutletmonthlyregisterid,
					outletid,
					month,
					year,
					status,
					createdby,
					createddate,
					modifiedby,
					modifieddate
					--partialplan,
					--partialstatus,
					--reject_note,
					--approval_note
				)
				values
				(
					begin_rg_id,
					partial_rc.outletid,
					partial_rc.month,
					partial_rc.year,
					100,
					partial_rc.createdby,
					partial_rc.createddate,
					partial_rc.modifiedby,
					partial_rc.modifieddate
					--partial_rc.partialplan,
					--partial_rc.partialstatus,
					--partial_rc.reject_note,
					--partial_rc.approval_note
				);
				ELSE begin_rg_id = partial_rc.mr_id;
				END IF;
				IF (partial_rc.mrt_id is null) THEN
				select nextval('fcvplatform.psoutletmonthlyregistertemp_psoutletmonthlyregisterid_seq') INTO begin_rg_temp_id;
				INSERT INTO fcvplatform.psoutletmonthlyregistertemp
				(
					psoutletmonthlyregisterid,
					outletid,
					month,
					year,
					status,
					createdby,
					createddate,
					modifiedby,
					modifieddate
					--typeplan,
					--partialplan,
					--partialstatus,
					--reject_note,
					--approval_note
				)
				values
				(
					begin_rg_temp_id,
					partial_rc.outletid,
					partial_rc.month,
					partial_rc.year,
					100,
					partial_rc.createdby,
					partial_rc.createddate,
					partial_rc.modifiedby,
					partial_rc.modifieddate
					--partial_rc.typeplan,
					--partial_rc.partialplan,
					--partial_rc.partialstatus,
					--partial_rc.reject_note,
					--partial_rc.approval_note
				);
				ELSE begin_rg_temp_id = partial_rc.mrt_id;
				END IF;
			END IF;
		END IF;
		IF (partial_rc.actiontype = 1000 or partial_rc.actiontype = 1001) THEN
			INSERT INTO fcvplatform.psoutletmonthlyregisterdetail
			(
				psoutletmonthlyregisterid,
				psoutletmodelsettingid,
				expectcutoff,
				commitcutoff,
				commitnote,
				displaycost,
				displaylocationid,
				locationcost,
				outletmodelgroupid,
				outletmodelid,
				--outletmodeloldid,
				locationnote,
				model_note,
				--partialplan,
				--partialstatus,
				cashier
			)
			values
			(
				begin_rg_id,
				partial_rc.psoutletmodelsettingid,
				partial_rc.expectcutoff,
				partial_rc.commitcutoff,
				partial_rc.commitnote,
				partial_rc.displaycost,
				partial_rc.displaylocationid,
				partial_rc.locationcost,
				partial_rc.outletmodelgroupid,
				partial_rc.outletmodelid,
				--partial_rc.outletmodeloldid,
				partial_rc.locationnote,
				partial_rc.model_note,
				--partial_rc.partialplan,
				--partial_rc.partialstatus,
				partial_rc.cashier
			);
			INSERT INTO fcvplatform.psoutletmonthlyregisterdetailtemp
			(
				psoutletmonthlyregisterid,
				psoutletmodelsettingid,
				expectcutoff,
				commitcutoff,
				commitnote,
				displaycost,
				displaylocationid,
				locationcost,
				outletmodelgroupid,
				outletmodelid,
				--outletmodeloldid,
				locationnote,
				model_note,
				--partialplan,
				--partialstatus,
				cashier
			)
			values
			(
				begin_rg_temp_id,
				partial_rc.psoutletmodelsettingid,
				partial_rc.expectcutoff,
				partial_rc.commitcutoff,
				partial_rc.commitnote,
				partial_rc.displaycost,
				partial_rc.displaylocationid,
				partial_rc.locationcost,
				partial_rc.outletmodelgroupid,
				partial_rc.outletmodelid,
				--partial_rc.outletmodeloldid,
				partial_rc.locationnote,
				partial_rc.model_note,
				--partial_rc.partialplan,
				--partial_rc.partialstatus,
				partial_rc.cashier
			);
		ELSE
		   DELETE FROM fcvplatform.psoutletmonthlyregisterdetailtemp
		   WHERE psoutletmonthlyregisterid = partial_rc.mrt_id
		   AND outletmodelgroupid = partial_rc.outletmodelgroupid;

		   DELETE FROM fcvplatform.psoutletmonthlyregisterdetail
		   WHERE psoutletmonthlyregisterid = partial_rc.mr_id
		   AND outletmodelgroupid = partial_rc.outletmodelgroupid;
		END IF;
	   END IF;
	   UPDATE fcvplatform.psoutletmonthlyregisterpartial r
	   SET status = next_status
	   WHERE r.psoutletmonthlyregisterpartialid = partial_rc.psoutletmonthlyregisterpartialid;
	END LOOP;
   END LOOP;
   IF (current_status = 100) THEN
	return 100;
   END IF;
return 1;
END;
$$;
