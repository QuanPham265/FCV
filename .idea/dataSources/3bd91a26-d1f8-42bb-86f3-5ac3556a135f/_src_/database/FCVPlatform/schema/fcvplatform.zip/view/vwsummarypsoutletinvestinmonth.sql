CREATE VIEW vwsummarypsoutletinvestinmonth AS SELECT outletmodel.outletmodelid,
    outletmodelgroup.outletmodelgroupid,
    psoutletmonthlyregister.outletid,
    (sum(psoutletmonthlyregisterdetail.displaycost) + sum(psoutletmonthlyregisterdetail.locationcost)) AS invest,
    outletmodel.name AS outletmodelname,
    outletmodelgroup.name AS outletmodelgroupname,
    sum(psoutletmonthlyregisterdetail.locationcost) AS locationcost,
    sum(psoutletmonthlyregisterdetail.displaycost) AS displaycost,
    psoutletmonthlyregisterdetail.displaylocationid,
    psoutletmonthlyregister.month,
    psoutletmonthlyregister.year,
    to_date(((psoutletmonthlyregister.month || ''::text) || psoutletmonthlyregister.year), 'MMyyyy'::text) AS monthyear,
    psoutletmonthlyregister.status,
    psoutletmonthlyregister.statuslocationcost,
    psoutletmonthlyregisterdetail.commitnote
   FROM ((((fcvplatform.outletmodel outletmodel
     JOIN fcvplatform.psoutletmodelsetting psoutletmodelsetting ON ((psoutletmodelsetting.outletmodelid = outletmodel.outletmodelid)))
     JOIN fcvplatform.psoutletmonthlyregisterdetail psoutletmonthlyregisterdetail ON ((psoutletmonthlyregisterdetail.psoutletmodelsettingid = psoutletmodelsetting.psoutletmodelsettingid)))
     JOIN fcvplatform.psoutletmonthlyregister psoutletmonthlyregister ON ((psoutletmonthlyregister.psoutletmonthlyregisterid = psoutletmonthlyregisterdetail.psoutletmonthlyregisterid)))
     JOIN fcvplatform.outletmodelgroup outletmodelgroup ON ((outletmodelgroup.outletmodelgroupid = outletmodel.outletmodelgroupid)))
  GROUP BY outletmodel.outletmodelid, outletmodelgroup.outletmodelgroupid, psoutletmonthlyregister.outletid, psoutletmonthlyregisterdetail.displaylocationid, psoutletmonthlyregister.status, psoutletmonthlyregister.statuslocationcost, psoutletmonthlyregisterdetail.commitnote, psoutletmonthlyregister.month, psoutletmonthlyregister.year;
