CREATE VIEW vw_missing_phonenumber_customer AS SELECT DISTINCT ( SELECT dt.a[array_length(regexp_split_to_array(rtrim((mr.messagein)::text, ' '::text), ' '::text), 1)] AS a
           FROM ( SELECT regexp_split_to_array(rtrim((mr.messagein)::text, ' '::text), ' '::text) AS regexp_split_to_array) dt(a)) AS phonemissing,
    mr.customerid,
    c.name,
    c.code,
    mr.messagein AS smsreceive,
    mr.createddate AS smsdate
   FROM (fcvplatform.messagereceive mr
     LEFT JOIN fcvplatform.customer c ON ((c.customerid = mr.customerid)))
  WHERE ((mr.customerid IS NOT NULL) AND (c.phonenumber IS NULL) AND (mr.messageout ~~ ( SELECT tmp.content
           FROM fcvplatform.defaultnoticetemplate tmp
          WHERE ((tmp.code)::text = 'LoyaltyRegisterToSalesman'::text))) AND (NOT (mr.customerid IN ( SELECT historychange.customerid
           FROM fcvplatform.historychange
          WHERE ((historychange.code = 'UPDATE_PHONE_CUSTOMER'::text) AND ((historychange.content ~~ '%"afterUpdate":""%'::text) OR (historychange.content ~~ '%"afterUpdate":"\\"\\""%'::text)))))) AND (NOT (mr.customerid IN ( SELECT c_1.customerid
           FROM (fcvplatform.changeinforequest c_1
             LEFT JOIN fcvplatform.changeinforequestdetail ci ON ((ci.changeinforequestid = c_1.changeinforequestid)))
          WHERE ((c_1.status = 3) AND (ci.newvalue IS NULL))))) AND ((c.statusmerge = false) OR (c.statusmerge IS NULL)));
