create function fn_summary_partial_register(p_distributorid bigint, p_month integer, p_year integer, statusapprove integer[]) returns integer
LANGUAGE plpgsql
AS $$
declare p_totalDeleteOnePart integer DEFAULT 0;
  declare p_totalDeleteFullPart integer DEFAULT 0;
  declare p_totalAddOnePart integer DEFAULT 0;
  declare p_totalAddFullPart integer DEFAULT 0;
  declare p_totalOutletPreviousMonth integer DEFAULT 0;
  declare count_rc record;
BEGIN
  IF(p_distributorId IS NULL OR p_month IS NULL OR p_year IS NULL) THEN
    return 0;
  END IF;

  FOR count_rc in (select COUNT(p.outletid) count, p.actiontype from fcvplatform.psoutletmonthlyregisterpartial p
    INNER JOIN ( select distinct o.psoutletid from fcvplatform.vw_sub_perfect_store_usermanager_outlet o
    where o.distributorid = p_distributorId) o on o.psoutletid = p.outletid
  where p.month = p_month and p.year = p_year and p.status = ANY (statusapprove)
  GROUP BY p.actiontype)
  LOOP
    IF(count_rc.actiontype = 1001) THEN
      p_totalAddFullPart := count_rc.count;
    END IF;

    IF(count_rc.actiontype = 1000) THEN
      p_totalAddOnePart := count_rc.count;
    END IF;

    IF(count_rc.actiontype = 1010) THEN
      p_totalDeleteOnePart := count_rc.count;
    END IF;

    IF(count_rc.actiontype = 1011) THEN
      p_totalDeleteFullPart := count_rc.count;
    END IF;
  END LOOP;

  select COUNT(p.outletid) into p_totalOutletPreviousMonth from fcvplatform.psoutletmonthlyregister_bk_final p
    INNER JOIN ( select distinct o.psoutletid from fcvplatform.vw_sub_perfect_store_usermanager_outlet o
    where o.distributorid = p_distributorId) o on o.psoutletid = p.outletid
  where p.month = p_month and p.year = p_year;

  IF(select exists(select 1 from fcvplatform.pssummarypartialregister s where s.distributorid = p_distributorId and s.month = p_month and s.year = p_year)) THEN
    BEGIN
      update fcvplatform.pssummarypartialregister set totaladdfullpart = p_totalAddFullPart, totaladdonepart = p_totalAddOnePart,
        totaldeleteonepart = p_totalDeleteOnePart, totaldeletefullpart = p_totalDeleteFullPart, totaloutletregister = p_totalOutletPreviousMonth
      where distributorid = p_distributorId and month = p_month and year = p_year;
    END;
  ELSE
    BEGIN
      insert into fcvplatform.pssummarypartialregister(
        distributorid,
        totaloutletregister,
        totaldeletefullpart,
        totaldeleteonepart,
        totaladdonepart,
        totaladdfullpart,
        month,
        year,
        createddate) values(
        p_distributorId,
        p_totalOutletPreviousMonth,
        p_totalDeleteFullPart,
        p_totalDeleteOnePart,
        p_totalAddOnePart,
        p_totalAddOnePart,
        p_month,
        p_year,
        now());
    END;
  END IF;

  return 1;
END;
$$;
