CREATE MATERIALIZED VIEW vw_invoice_copy AS WITH dmsoutletids AS (
         SELECT dmsoutlet.dmsoutletid
           FROM fcvplatform.dmsoutlet
          WHERE ((dmsoutlet.code)::text IN ( SELECT mergecustomerlog.customeroldcode
                   FROM fcvplatform.mergecustomerlog
                  WHERE ((mergecustomerlog.status)::text = 'NEW'::text)))
        )
 SELECT dmsinvoice.invoiceid,
    dmsinvoice.dmsoutletid,
    dmsinvoice.issueddate,
    dmsinvoice.invoicecode,
    dmsinvoice.totalcost,
    dmsinvoice.createddate,
    dmsinvoice.prioritycode,
    dmsinvoice.description,
    dmsinvoice.discountamount,
    dmsinvoice.totaltax,
    dmsinvoice.statecode,
    dmsinvoice.statuscode,
    dmsinvoice.versionnumber,
    dmsinvoice.idhashcode,
    dmsinvoice.invoiceno,
    dmsinvoice.statusmerge,
    dmsinvoice.orderno,
    dmsinvoice.mergefromid,
    dmsinvoice.mergedate,
    dmsinvoice.statusread,
    dmsinvoice.mergetoid
   FROM fcvplatform.dmsinvoice
  WHERE (dmsinvoice.dmsoutletid = ANY (ARRAY( SELECT dmsoutletids.dmsoutletid
           FROM dmsoutletids)));
CREATE INDEX in_invoiceid_vw_invoice_copy
  ON vw_invoice_copy (invoiceid);
CREATE INDEX in_dmsoutletid_vw_invoice_copy
  ON vw_invoice_copy (dmsoutletid);
