create function fn_generatesubdis() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN SELECT * FROM distributor
  where distributorid not in (231,8,14,18,22,23,25,26,27,28,31,32,33,34,35
    ,36,38,40,42,43,45,46,47,48,53,57,62,74,76,77,81,85,87,93,94,96,98,221,222,232
  ,168)
        and status = 0
  LOOP
    BEGIN
      INSERT INTO subdistributor (
        parentdistributorid,
        code,
        name,
        regionid,
        status,
        cityid,
        prefix,
        addr1,
        addr2,
        addr3,
        addr4,
        seid,
        ismain
      )
      VALUES (
        rec.distributorid,
        rec.code,
        rec.name,
        rec.regionid,
        rec.status,
        rec.cityid,
        rec.prefix,
        rec.addr1,
        rec.addr2,
        rec.addr3,
        rec.addr4,
        (
          with rs as(
            with rs as (
                select userid as seId, count(staffuserid) as countSM from linemanager l where
                  l.staffuserid is not null
                  and exists(select 1 from users u where u.userid = l.userid
                                                         and u.usergroupid = (select usergroupid from usergroup WHERE code = 'SE'))
                GROUP BY userid
            )
            select userid, rs.countSM as countSM
            from linemanager l1 INNER JOIN rs on l1.userid = rs.seId
            WHERE l1.distributorid = rec.distributorid
            ORDER BY countSM DESC limit 1
          )
          select userid from rs
        ),
        true
      );
    END;
  END LOOP;
END;
$$;
