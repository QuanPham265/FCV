CREATE VIEW vw_sub_dis_se_sm AS SELECT u.seid,
    u.se_username,
    u.se_fullname,
    u.se_role,
    sd.distributorid,
    sd.code AS distributorcode,
    u.distributorname,
    u.smid,
    u.sm_username,
    u.sm_fullname
   FROM (fcvplatform.vw_dis_se_sm u
     JOIN fcvplatform.subdistributor sd ON ((u.distributorid = sd.parentdistributorid)));
