CREATE MATERIALIZED VIEW vsummaryamountbyregionandcatgroupmonthly AS SELECT cat.catgroupid,
    cat.name AS catgroupname,
    cat.code AS catgroupcode,
    r.regionid,
    r.name AS regionname,
    date_part('month'::text, d.issueddate) AS month,
    date_part('year'::text, d.issueddate) AS year,
    sum(dd.cost) AS total
   FROM (((((((fcvplatform.dmsinvoicedetail dd
     JOIN fcvplatform.dmsinvoice d ON ((dd.invoiceid = d.invoiceid)))
     JOIN fcvplatform.product p ON ((dd.productid = p.productid)))
     JOIN fcvplatform.productgroup pg ON ((p.productgroupid = pg.productgroupid)))
     JOIN fcvplatform.catgroup cat ON ((pg.catgroupid = cat.catgroupid)))
     JOIN fcvplatform.dmsoutlet o ON ((o.dmsoutletid = d.dmsoutletid)))
     JOIN fcvplatform.distributor di ON ((di.distributorid = o.distributorid)))
     JOIN fcvplatform.region r ON ((r.regionid = di.regionid)))
  GROUP BY cat.catgroupid, cat.name, cat.code, r.regionid, r.name, (date_part('month'::text, d.issueddate)), (date_part('year'::text, d.issueddate));
CREATE INDEX vsummaryamountbyregionandcatgroupmonthly_month_year_idx
  ON vsummaryamountbyregionandcatgroupmonthly (month, year);
