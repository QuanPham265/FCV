CREATE MATERIALIZED VIEW vsummarypointcycleofcustomerbymonth AS SELECT c.cycleid,
    ct.customerid,
    date_part('month'::text, ct.transactiontime) AS month,
    date_part('year'::text, ct.transactiontime) AS year,
    sum(COALESCE(ct.earnedpoint, (0)::numeric)) AS invoicepoint,
    sum((COALESCE(ct.bonuspointforrank, (0)::numeric) + COALESCE(ct.bonuspointnotforrank, (0)::numeric))) AS bonuspoint,
    (0)::numeric AS carepoint
   FROM ((fcvplatform.cumulativetransaction ct
     JOIN fcvplatform.campaign c ON ((ct.campaignid = c.campaignid)))
     JOIN fcvplatform.cycle cy ON ((c.cycleid = cy.cycleid)))
  WHERE (date(ct.transactiontime) >= date(cy.startdate))
  GROUP BY (date_part('month'::text, ct.transactiontime)), (date_part('year'::text, ct.transactiontime)), c.cycleid, ct.customerid
  ORDER BY c.cycleid, ct.customerid, (date_part('year'::text, ct.transactiontime)), (date_part('month'::text, ct.transactiontime));
CREATE INDEX summarypointcycleofcustomerbymonth_customer_cycle_idx
  ON vsummarypointcycleofcustomerbymonth (cycleid, customerid);
