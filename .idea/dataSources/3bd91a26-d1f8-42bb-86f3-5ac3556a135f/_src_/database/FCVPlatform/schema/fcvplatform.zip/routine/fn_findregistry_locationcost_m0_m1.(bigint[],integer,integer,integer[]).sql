create function fn_findregistry_locationcost_m0_m1(d_distributorid bigint[], month_m0 integer, year_m0 integer, status_m0 integer[]) returns TABLE(outletid bigint, o_code text, o_name text, sub_distributorid bigint, sd_code text, sd_name text, m0_locationcost numeric, m1_locationcost numeric)
LANGUAGE plpgsql
AS $$
declare year_m1 integer;
declare month_m1 integer;
BEGIN
month_m1 = month_m0 - 1;
year_m1 = year_m0;
if (month_m0 = 1) then 
	month_m1 = 12;
	year_m1 = year_m0 - 1;
end if;

RETURN QUERY 
with rg_old as (
select  r.outletid,
	v.sub_distributorid,
	sum(COALESCE(rd.locationcost, 0)) locationcost
from fcvplatform.psoutletmonthlyregistertemp  r
inner join fcvplatform.psoutletmonthlyregisterdetailtemp rd
on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
inner join fcvplatform.psoutlet v on r.outletid = v.outletid 
inner join fcvplatform.subdistributor sd on sd.distributorid = v.sub_distributorid
where r.month = month_m1 and r.year = year_m1 and r.status = 100
and v.sub_distributorid = ANY (d_distributorid)
group by v.sub_distributorid, r.outletid
)
select  rg_new.outletid,
	cast(rg_new.o_code as text),
	cast(rg_new.o_name as text),
	rg_new.sub_distributorid,
	cast(rg_new.sd_code as text),
	cast(rg_new.sd_name as text),
	rg_new.locationcost m0_locationcost,
	rg_old.locationcost m1_locationcost
from (
select  v.outletid,
	v.code o_code,
	v.name o_name,
	v.sub_distributorid,
	sd.code sd_code,
	sd.name sd_name,
	sum(COALESCE(rd.locationcost, 0)) locationcost
from fcvplatform.psoutletmonthlyregistertemp  r
inner join fcvplatform.psoutletmonthlyregisterdetailtemp rd
on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
inner join fcvplatform.psoutlet v on r.outletid = v.outletid 
inner join fcvplatform.subdistributor sd on sd.distributorid = v.sub_distributorid
where r.month = month_m0 and r.year = year_m0  and (-1 = ANY (status_m0) or r.status = ANY (status_m0))
and v.sub_distributorid = ANY (d_distributorid)
group by v.sub_distributorid, v.outletid, sd.code, sd.name
) rg_new
left join rg_old on rg_old.outletid = rg_new.outletid
where 1=1
and (rg_new.locationcost is not null and (COALESCE(rg_new.locationcost, 0) > COALESCE(rg_old.locationcost, 0)));

END;
$$;
