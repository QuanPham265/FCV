CREATE VIEW vw_perfect_store_usermanager_outlet AS WITH vw_perfect_store_usermanager AS (
         SELECT DISTINCT ON (vw_perfect_store_usermanager.nnwid, vw_perfect_store_usermanager.rsmid, vw_perfect_store_usermanager.regionid, vw_perfect_store_usermanager.asmid, vw_perfect_store_usermanager.cityid, vw_perfect_store_usermanager.seid, vw_perfect_store_usermanager.distributorid) vw_perfect_store_usermanager.nnwid,
            vw_perfect_store_usermanager.nnw_username,
            vw_perfect_store_usermanager.nnw_fullname,
            vw_perfect_store_usermanager.rsmid,
            vw_perfect_store_usermanager.rsm_username,
            vw_perfect_store_usermanager.rsm_fullname,
            vw_perfect_store_usermanager.regionid,
            vw_perfect_store_usermanager.regionname,
            vw_perfect_store_usermanager.asmid,
            vw_perfect_store_usermanager.asm_username,
            vw_perfect_store_usermanager.asm_fullname,
            vw_perfect_store_usermanager.cityid,
            vw_perfect_store_usermanager.cityname,
            vw_perfect_store_usermanager.seid,
            vw_perfect_store_usermanager.se_username,
            vw_perfect_store_usermanager.se_fullname,
            vw_perfect_store_usermanager.distributorid,
            vw_perfect_store_usermanager.distributorcode,
            vw_perfect_store_usermanager.distributorname,
            vw_perfect_store_usermanager.smid,
            vw_perfect_store_usermanager.sm_username,
            vw_perfect_store_usermanager.sm_fullname
           FROM fcvplatform.vw_perfect_store_usermanager
        )
 SELECT u.nnwid,
    u.nnw_username,
    u.nnw_fullname,
    u.rsmid,
    u.rsm_username,
    u.rsm_fullname,
    u.regionid,
    u.regionname,
    u.asmid,
    u.asm_username,
    u.asm_fullname,
    u.cityid,
    u.cityname,
    u.seid,
    u.se_username,
    u.se_fullname,
    u.distributorid,
    u.distributorcode,
    u.distributorname,
    users.userid AS smid,
    users.username AS sm_username,
    users.fullname AS sm_fullname,
    psoutlet.outletid AS psoutletid,
    psoutlet.code AS psoutletcode,
    psoutlet.name AS psoutletname,
    psoutlet.name AS outletname,
    psoutlet.dmsoutletid AS outletid
   FROM (((fcvplatform.psoutlet psoutlet
     LEFT JOIN fcvplatform.linemanager lm ON ((lm.outletid = psoutlet.dmsoutletid)))
     LEFT JOIN fcvplatform.users users ON ((users.userid = lm.userid)))
     JOIN vw_perfect_store_usermanager u ON ((u.distributorid = psoutlet.distributorid)))
  WHERE ((psoutlet.status = 1) AND ((psoutlet.statusmerge IS NULL) OR (psoutlet.statusmerge = false)) AND (EXISTS ( SELECT 1
           FROM fcvplatform.linemanager lm1
          WHERE ((lm1.userid = u.seid) AND ((lm.userid IS NULL) OR (lm1.staffuserid = lm.userid))))));
