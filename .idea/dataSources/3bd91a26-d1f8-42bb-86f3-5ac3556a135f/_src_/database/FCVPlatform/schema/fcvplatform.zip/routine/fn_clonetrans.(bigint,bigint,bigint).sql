create function fn_clonetrans(fromid bigint, toid bigint, incycleid bigint) returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN SELECT * FROM cumulativetransaction t INNER JOIN campaign c on t.campaignid = c.campaignid and c.cycleid = inCycleId WHERE customerid = fromId LOOP
    BEGIN
      INSERT INTO cumulativetransaction (transactiontype,transactiontime,status,customerid,earnedpoint,invoiceamount,bonuspointforrank,bonuspointnotforrank,campaignid,invoicenumber,cyclerankingid,redemptionpoint,
                                         createddate,statecode)
      VALUES (rec.transactiontype,rec.transactiontime,rec.status,toId,rec.earnedpoint,rec.invoiceamount,rec.bonuspointforrank,rec.bonuspointnotforrank,
                                  rec.campaignid,cast(rec.invoicenumber || '_' || toId as TEXT),rec.cyclerankingid,rec.redemptionpoint,rec.createddate,rec.statecode
      );
    END;
  END LOOP;
END;
$$;
