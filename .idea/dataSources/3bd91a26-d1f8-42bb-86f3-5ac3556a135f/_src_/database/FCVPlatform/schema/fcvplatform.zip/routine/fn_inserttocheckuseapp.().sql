create function fn_inserttocheckuseapp() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
      FOR rec IN
      with customers as (
          select customerid from customer WHERE
                needchangepassword <> true
                and (statusmerge is null or customer.statusmerge = false)
      )
      select customerid as customerid ,EXTRACT(month from createddate) as month, EXTRACT(year from createddate) as year  from messagesent
      where messageout like '%mat khau%' and messagesent.gatewaystatus = 200
            and messagesent.customerid in (select customerid from customers)
      group by customerid,month,year

      UNION ALL

      select customerid as customerid ,EXTRACT(month from requestdate) as month, EXTRACT(year from requestdate) as year  from giftexchangerequest
      WHERE source = 'App'
      LOOP
            BEGIN
                  IF cast( (select count(*) from checkuseapp where customerid = rec.customerid and month = rec.month and year = rec.year) as integer) = 0 THEN
                        INSERT INTO checkuseapp (
                              customerid,
                              month,
                              year
                        ) VALUES (
                              rec.customerid,
                              rec.month,
                              rec.year
                        );
                  END IF;

            END;
      END LOOP;
END;
$$;
