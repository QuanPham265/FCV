CREATE VIEW vw_dis_se_sm AS WITH seid_smid AS (
         WITH smid AS (
                 SELECT DISTINCT ON (lm_7.userid) lm_7.userid AS smid,
                    u_2.username AS sm_username,
                    u_2.fullname AS sm_fullname
                   FROM (fcvplatform.linemanager lm_7
                     JOIN fcvplatform.users u_2 ON ((u_2.userid = lm_7.userid)))
                  WHERE (lm_7.outletid IS NOT NULL)
                )
         SELECT DISTINCT ON (smid.smid) lm_6.userid AS seid,
            u_1.username AS se_username,
            u_1.fullname AS se_fullname,
            role.code AS se_role,
            smid.smid,
            smid.sm_username,
            smid.sm_fullname
           FROM ((((fcvplatform.linemanager lm_6
             JOIN smid ON ((smid.smid = lm_6.staffuserid)))
             JOIN fcvplatform.users u_1 ON ((u_1.userid = lm_6.userid)))
             LEFT JOIN fcvplatform.userroleacl ON ((lm_6.userid = userroleacl.userid)))
             LEFT JOIN fcvplatform.role ON (((userroleacl.roleid = role.roleid) AND ((role.code)::text = 'SE_CY'::text))))
        )
 SELECT seid_smid.seid,
    seid_smid.se_username,
    seid_smid.se_fullname,
    seid_smid.se_role,
    seid_smid.smid,
    seid_smid.sm_username,
    seid_smid.sm_fullname,
    lm_1.distributorid,
    d.code AS distributorcode,
    d.name AS distributorname
   FROM ((fcvplatform.linemanager lm_1
     JOIN seid_smid ON ((seid_smid.seid = lm_1.userid)))
     LEFT JOIN fcvplatform.distributor d ON ((d.distributorid = lm_1.distributorid)))
  WHERE (lm_1.distributorid IS NOT NULL);
