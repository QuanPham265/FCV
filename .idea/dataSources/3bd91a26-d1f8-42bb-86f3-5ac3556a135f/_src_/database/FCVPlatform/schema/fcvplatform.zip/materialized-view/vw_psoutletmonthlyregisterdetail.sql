CREATE MATERIALIZED VIEW vw_psoutletmonthlyregisterdetail AS SELECT o.code AS outletcode,
    o.name AS outletname,
    r.month,
    r.year,
    om.code AS outletmodelcode,
    om.perfectcode,
    om.name AS outletmodelname,
    rd.locationcost,
    r.statuslocationcost,
    rd.displaycost,
    rd.displaylocationid AS displaylocation,
    rd.cashier
   FROM fcvplatform.psoutletmonthlyregister r,
    fcvplatform.psoutlet o,
    fcvplatform.psoutletmonthlyregisterdetail rd,
    fcvplatform.outletmodel om
  WHERE ((r.outletid = o.outletid) AND (r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid) AND (rd.outletmodelid = om.outletmodelid) AND (r.status = 100))
  ORDER BY r.year DESC, r.month DESC, o.code;
