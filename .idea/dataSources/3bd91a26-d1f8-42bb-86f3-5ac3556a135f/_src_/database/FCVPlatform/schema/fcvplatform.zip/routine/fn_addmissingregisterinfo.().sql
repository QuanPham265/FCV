create function fn_addmissingregisterinfo() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN
  select * from messagereceive m
  WHERE lower(messageout) like '%ban da dang ky chuong trinh khtt cho cua hang thanh cong%'
        and m.customerid is not null
        and not exists(select 1 from customercycleregister r WHERE r.customerid = m.customerid and m.messagein = r.smscontent)
  LOOP
    BEGIN
      IF cast( (select count(*) from customercycleregister where customerid = rec.customerid and cycleid = 5) as integer) = 0 THEN

        INSERT INTO customercycleregister (
          smscontent,
          cycleid,
          customerid,
          statuscode,
          statecode,
          createddate
        ) VALUES (
          rec.messagein,
          5,
          rec.customerid,
          1,
          0,
          rec.createddate
        );

      END IF;
      

    END;
  END LOOP;
END;
$$;
