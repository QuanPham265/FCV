create function updatecustomeruseapp() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
        recUseApp Record;
        varCheckUseAppId BIGINT;
BEGIN
  FOR rec IN  SELECT customerid, idnew FROM FCVPlatform.customer WHERE statusmerge = TRUE AND idnew IS NOT NULL ORDER BY customerid LOOP
    FOR recUseApp IN SELECT checkuseappid, month, year, days, useapp FROM FcvPlatform.checkuseapp WHERE customerid = rec.customerId LOOP
      SELECT checkuseappid INTO varCheckUseAppId FROM FCVPlatform.checkuseapp cu WHERE cu.customerid = rec.idnew AND cu.year = recUseApp.year And cu.month = recUseApp.month;
      IF varCheckUseAppId IS NOT NULL THEN
        UPDATE FCVPlatform.checkuseapp set days = concat(days, ',', recUseApp.days), useapp = concat(useapp, ',', recUseApp.useapp) WHERE checkuseappid = varCheckUseAppId;
        DELETE FROM FCVPlatform.checkuseapp WHERE checkuseappid = recUseApp.checkuseappid;
      ELSE
        UPDATE FCVPlatform.checkuseapp set CustomerId = rec.idnew, exId = rec.customerid WHERE checkuseappid = recUseApp.checkuseappid;
      END IF;
    END LOOP;
  END LOOP;
END;
$$;
