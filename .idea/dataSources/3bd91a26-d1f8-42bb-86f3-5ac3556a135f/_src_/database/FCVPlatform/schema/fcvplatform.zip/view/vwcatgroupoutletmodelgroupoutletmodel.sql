CREATE VIEW vwcatgroupoutletmodelgroupoutletmodel AS SELECT catgroup.catgroupid,
    outletmodelgroup.outletmodelgroupid,
    outletmodel.outletmodelid,
    catgroup.code AS catgroupcode,
    outletmodelgroup.code AS outletmodelgroupcode,
    outletmodel.code AS outletmodecode,
    catgroup.name AS catgroupname,
    outletmodelgroup.name AS outletmodelgroupname,
    outletmodel.name AS outletmodelname,
    outletmodeldetail.outletmodeldetailid,
    outletmodeldetail.datatype,
    outletmodeldetail.referencevalue,
    outletmodelgroup.perfectcode AS outletmodelgroupperfectcode,
    outletmodel.perfectcode AS outletmodelperfectcode,
    outletmodelgroup.iscashier,
    outletmodelgroup.islocationcost,
    outletmodelgroup.istargets,
    outletmodel.outletmodel_note,
    outletmodel.cashier_note,
    catgroup.display_order AS c_display_order,
    outletmodelgroup.display_order AS g_display_order
   FROM (((fcvplatform.outletmodel outletmodel
     JOIN fcvplatform.catgroup ON ((catgroup.catgroupid = outletmodel.catgroupid)))
     JOIN fcvplatform.outletmodelgroup ON ((outletmodelgroup.outletmodelgroupid = outletmodel.outletmodelgroupid)))
     LEFT JOIN fcvplatform.outletmodeldetail ON ((outletmodeldetail.outletmodelid = outletmodel.outletmodelid)))
  WHERE ((NOT (outletmodel.outletmodelid IN ( SELECT outletmodel1.parentid
           FROM fcvplatform.outletmodel outletmodel1
          WHERE (outletmodel1.parentid IS NOT NULL)))) AND (catgroup.active = true) AND (outletmodelgroup.active = true) AND (outletmodel.active = true))
  ORDER BY catgroup.catgroupid, outletmodelgroup.outletmodelgroupid, outletmodel.outletmodelid;
