CREATE MATERIALIZED VIEW vwpsoutletprofile AS WITH vw_perfect_store_usermanager AS (
         SELECT DISTINCT ON (vw_perfect_store_usermanager.nnwid, vw_perfect_store_usermanager.rsmid, vw_perfect_store_usermanager.regionid, vw_perfect_store_usermanager.asmid, vw_perfect_store_usermanager.cityid, vw_perfect_store_usermanager.seid, vw_perfect_store_usermanager.distributorid) vw_perfect_store_usermanager.nnwid,
            vw_perfect_store_usermanager.nnw_username,
            vw_perfect_store_usermanager.nnw_fullname,
            vw_perfect_store_usermanager.rsmid,
            vw_perfect_store_usermanager.rsm_username,
            vw_perfect_store_usermanager.rsm_fullname,
            vw_perfect_store_usermanager.regionid,
            vw_perfect_store_usermanager.regionname,
            vw_perfect_store_usermanager.asmid,
            vw_perfect_store_usermanager.asm_username,
            vw_perfect_store_usermanager.asm_fullname,
            vw_perfect_store_usermanager.cityid,
            vw_perfect_store_usermanager.cityname,
            vw_perfect_store_usermanager.seid,
            vw_perfect_store_usermanager.se_username,
            vw_perfect_store_usermanager.se_fullname,
            vw_perfect_store_usermanager.distributorid,
            vw_perfect_store_usermanager.distributorcode,
            vw_perfect_store_usermanager.distributorname,
            vw_perfect_store_usermanager.smid,
            vw_perfect_store_usermanager.sm_username,
            vw_perfect_store_usermanager.sm_fullname
           FROM fcvplatform.vw_perfect_store_usermanager
        )
 SELECT psoutlet.name AS psoutletname,
    psoutlet.street AS psoutletstreet,
    psoutlet.locationno AS psoutletlocationno,
    psoutlet.phonenumber AS psoutletphonenumber,
    psoutlet.email AS psoutletemail,
    psoutlet.idno AS psoutletidno,
    psoutlet.bankaccount AS psoutletbankaccount,
    u.distributorcode,
    u.distributorname,
    u.regionname,
    ''::text AS statename,
    psoutlet.code AS psoutletcode,
    psoutlet.ward AS psoutletward,
    u.cityname,
    psoutlet.district AS psoutletdistrict,
    psoutlet.bankaccountaddress,
    psoutlet.bankaccountname,
    psoutlet.outletid AS psoutletid,
    psoutlet.fullname,
    lm.description,
    users.fullname AS sm_fullname,
    users.username AS sm_username,
    users.userid AS smid,
    u.se_fullname,
    u.se_username,
    u.seid,
    u.asm_fullname,
    u.asm_username,
    u.asmid,
    u.rsm_fullname,
    u.rsm_username,
    u.rsmid,
    psoutlet.dmsoutletid,
    u.distributorid,
    u.cityid,
    u.regionid,
    lm.outletid,
    u.nnwid
   FROM (((fcvplatform.psoutlet psoutlet
     LEFT JOIN fcvplatform.linemanager lm ON ((lm.outletid = psoutlet.dmsoutletid)))
     LEFT JOIN fcvplatform.users users ON ((users.userid = lm.userid)))
     JOIN vw_perfect_store_usermanager u ON ((u.distributorid = psoutlet.distributorid)))
  WHERE ((psoutlet.status = 1) AND ((psoutlet.statusmerge IS NULL) OR (psoutlet.statusmerge = false)) AND (EXISTS ( SELECT 1
           FROM fcvplatform.linemanager lm1
          WHERE ((lm1.userid = u.seid) AND ((lm.userid IS NULL) OR (lm1.staffuserid = lm.userid))))));
CREATE INDEX in_outletid_vwpsoutletprofile
  ON vwpsoutletprofile (psoutletid);
CREATE INDEX in_seid_vwpsoutletprofile
  ON vwpsoutletprofile (seid);
CREATE INDEX in_dmsoutletid_vwpsoutletprofile
  ON vwpsoutletprofile (dmsoutletid);
CREATE INDEX in_distributorid_vwpsoutletprofile
  ON vwpsoutletprofile (distributorid);
CREATE INDEX in_regionid_vwpsoutletprofile
  ON vwpsoutletprofile (regionid);
