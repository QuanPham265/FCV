create function partial_register_rejected_revert_data(monthvar integer, yearvar integer, outletidvar bigint, type integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE psoutletmonthlyregisteridvar bigint;
        add_full_part CONSTANT integer := 1001; -- Bổ sung toàn phần
        add_one_part CONSTANT integer := 1000; -- Bổ sung 1 phần
        delete_full_part CONSTANT integer := 1011; -- Hủy toàn  phần
        delete_one_part CONSTANT integer := 1010; -- Hủy 1 phần
BEGIN
  --Reject ADD_ONE_PART
  IF type = add_one_part  THEN
    DELETE
    FROM fcvplatform.psoutletmonthlyregisterdetail rd
    WHERE exists(
              SELECT 1
              FROM fcvplatform.psoutletmonthlyregister r
              WHERE r.month = monthvar AND r.year = yearvar
                    AND r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
                    AND r.outletid = outletIdVar
          ) AND exists(
              SELECT *
              FROM fcvplatform.psoutletmonthlyregisterdetailpartial rdp
              WHERE rd2.outletmodelid = rdp.outletmodelid
                    AND exists(SELECT 1
                               FROM fcvplatform.psoutletmonthlyregisterpartial rp
                               WHERE rp.month = monthvar AND rp.year = yearvar
                                     AND rp.psoutletmonthlyregisterpartialid = rdp.psoutletmonthlyregisterpartialid
                                     AND rp.outletid = outletIdVar)
          );
  END IF;

  --Reject ADD_FULL_PART
  IF type = add_full_part THEN
    DELETE
    FROM fcvplatform.psoutletmonthlyregisterdetail rd
    WHERE exists(
        SELECT 1
        FROM fcvplatform.psoutletmonthlyregister r
        WHERE r.month = monthvar AND r.year = yearvar
              AND r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
              AND r.outletid = outletIdVar
    );
    DELETE
    FROM fcvplatform.psoutletmonthlyregister r
    WHERE r.month = monthvar AND r.year = yearvar AND r.outletid = outletIdVar;
  END IF;

  --Reject DELETE_FULL_PART
  IF type = delete_full_part THEN
    SELECT nextval('fcvplatform.psoutletmonthlyregister_psoutletmonthlyregisterid_seq') INTO psoutletmonthlyregisteridvar;

    INSERT INTO fcvplatform.psoutletmonthlyregister(psoutletmonthlyregisterid, outletid, month, year, status, createdby,
                                                    createddate, modifiedby, modifieddate, statuslocationcost, statusgroupplan,
                                                    typeplan, partialplan, partialstatus, reject_note, approval_note, isseapproved,
                                                    isasmapproved, isrsmapproved, isnnwapproved, forceeditrejectouttime)
      SELECT psoutletmonthlyregisteridvar, r.outletid, r.month, r.year, r.status, r.createdby, r.createddate, r.modifiedby,
        r.modifieddate, r.statuslocationcost, r.statusgroupplan, r.typeplan, r.partialplan, r.partialstatus, r.reject_note, r.approval_note,
        r.isseapproved, r.isasmapproved, r.isrsmapproved, r.isnnwapproved, r.forceeditrejectouttime
      FROM fcvplatform.psoutletmonthlyregister_bk_final r
      WHERE r.month = monthvar AND r.year = yearvar AND r.outletid = outletIdVar;

    INSERT INTO fcvplatform.psoutletmonthlyregisterdetail(psoutletmonthlyregisterdetailid, psoutletmonthlyregisterid,
                                                          psoutletmodelsettingid, expectcutoff, commitcutoff, commitnote,
                                                          displaycost, displaylocationid, locationcost, outletmodelgroupid,
                                                          outletmodelid, outletmodeloldid, locationnote, model_note, partialplan,
                                                          partialstatus, cashier)
      SELECT nextval('fcvplatform.psoutletmonthlyregisterdetail_psoutletmonthlyregisterdetail_seq'), psoutletmonthlyregisteridvar,
        psoutletmodelsettingid, expectcutoff, commitcutoff, commitnote, displaycost, displaylocationid, locationcost, outletmodelgroupid, outletmodelid, outletmodeloldid,
        locationnote, model_note, partialplan, partialstatus, cashier
      FROM fcvplatform.psoutletmonthlyregisterdetail_bk_final rd
      WHERE exists(
          SELECT 1
          FROM fcvplatform.psoutletmonthlyregister_bk_final r
          WHERE r.month = monthvar AND r.year = yearvar
                AND r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
                AND r.outletid = outletIdVar
      );
  END IF;

  --Reject DELETE_ONE_PART
  IF type = delete_one_part THEN
    SELECT psoutletmonthlyregisterid INTO psoutletmonthlyregisteridvar FROM fcvplatform.psoutletmonthlyregister r  WHERE r.month = monthvar AND r.year = yearvar AND r.outletid = outletIdVar;
    INSERT INTO fcvplatform.psoutletmonthlyregisterdetail(psoutletmonthlyregisterdetailid, psoutletmonthlyregisterid,
                                                          psoutletmodelsettingid, expectcutoff, commitcutoff, commitnote,
                                                          displaycost, displaylocationid, locationcost, outletmodelgroupid,
                                                          outletmodelid, outletmodeloldid, locationnote, model_note, partialplan,
                                                          partialstatus, cashier)
      SELECT nextval('fcvplatform.psoutletmonthlyregisterdetail_psoutletmonthlyregisterdetail_seq'), psoutletmonthlyregisteridvar, psoutletmodelsettingid, expectcutoff,
        commitcutoff, commitnote, displaycost, displaylocationid, locationcost, outletmodelgroupid, outletmodelid, outletmodeloldid,
        locationnote, model_note, partialplan, partialstatus, cashier
      FROM fcvplatform.psoutletmonthlyregisterdetail_bk_final rd
      WHERE exists(
                SELECT 1
                FROM fcvplatform.psoutletmonthlyregister_bk_final r
                WHERE r.month = monthvar AND r.year = yearvar
                      AND r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
                      AND r.outletid = outletIdVar
            ) AND NOT exists(
          SELECT *
          FROM fcvplatform.psoutletmonthlyregisterdetail rd2
          WHERE rd2.outletmodelid = rd.outletmodelid AND rd2.psoutletmonthlyregisterid = psoutletmonthlyregisteridvar
      );
  END IF;
END;
$$;
