create function update3psbudgettargetsdistributor(monthvar integer, yearvar integer, distributoridvar bigint[]) returns void
LANGUAGE plpgsql
AS $$
DECLARE statusDefault CONSTANT integer := 100;
        monthNextVar integer := monthvar + 1;
        yearNextVar integer := yearvar;
BEGIN
  IF monthvar = 12 THEN
    monthNextVar := 1;
    yearNextVar := yearvar + 1;
  END IF;

  -- clear data in 3 table target
  DELETE FROM fcvplatform.psbudgettargetsdistributordetail tdd
  WHERE EXISTS(SELECT *
               FROM fcvplatform.psbudgettargetsdistributor td
               WHERE td.psbudgettargetsdistributorid = tdd.psbudgettargetsdistributorid
                     AND td.month = monthNextVar
                     and td.year = yearNextVar
                     and td.distributorid = ANY (distributorIdVar));
  DELETE FROM fcvplatform.psbudgettargetsdistributorcatgroupdetail tdc
  WHERE EXISTS(SELECT *
               FROM fcvplatform.psbudgettargetsdistributor td
               WHERE td.psbudgettargetsdistributorid = tdc.psbudgettargetsdistributorid
                     AND td.month = monthNextVar
                     and td.year = yearNextVar
                     and td.distributorid = ANY (distributorIdVar));
  DELETE FROM fcvplatform.psbudgettargetsdistributor td WHERE td.month = monthNextVar and td.year = yearNextVar and td.distributorid = ANY (distributorIdVar);

  -- Function sync data for table 'psBudgetTargetsDistributor'
  INSERT INTO fcvplatform.psbudgettargetsdistributor (seid, asmid, distributorid, month, year, type)
    SELECT max(v.seid), max(v.asmid), alog.distributorid, monthNextVar, yearNextVar, 1
    FROM fcvplatform.psoutletmonthlyregister_bk_final alog, fcvplatform.vw_sub_perfect_store_usermanager v
    WHERE alog.month = monthVar and alog.year = yearVar and alog.distributorid = ANY (distributorIdVar) and alog.status = statusDefault AND v.distributorid = alog.distributorid
    GROUP BY alog.distributorid, alog.month, alog.year;

  -- Function sync data for table 'psBudgetTargetsDistributorDetail'
  WITH psoutletRegisterTableTmp AS (
      SELECT p.sub_distributorid, rd.outletmodelgroupid, rd.outletmodelid, count(DISTINCT(r.outletid)) totalOulet, sum(rd.displaycost) displaycostTotal, sum(rd.locationcost) locationcostTotal, (rd.cashier is null) isCashier
      FROM fcvplatform.psoutlet p
        INNER JOIN fcvplatform.psoutletmonthlyregister_bk_final r ON p.outletid = r.outletid
        INNER JOIN fcvplatform.psoutletmonthlyregisterdetail_bk_final rd ON r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
      WHERE r.month = monthVar AND r.year = yearVar AND r.status = statusDefault AND  p.sub_distributorid = ANY (distributorIdVar)
      GROUP BY p.sub_distributorid, rd.outletmodelgroupid, rd.outletmodelid, rd.cashier
  )
  INSERT INTO fcvplatform.psbudgettargetsdistributordetail (psbudgettargetsdistributorid, outletmodelgroupid, outletmodelid, totaloutlet, displaycost, locationcost, iscashier)
    SELECT td.psbudgettargetsdistributorid, ro.outletmodelgroupid, ro.outletmodelid, sum(ro.totalOulet), sum(ro.displaycostTotal), sum(ro.locationcostTotal), ro.isCashier
    FROM fcvplatform.psbudgettargetsdistributor td
      INNER JOIN psoutletRegisterTableTmp ro ON ro.sub_distributorid = td.distributorid
    WHERE td.month = monthNextVar AND td.year = yearNextVar
    GROUP BY psbudgettargetsdistributorid, ro.outletmodelgroupid, ro.outletmodelid, ro.isCashier;

  -- Function sync data for table 'psBudgetTargetsDistributorCatGroupDetail'
  WITH psoutletRegisterTableTmp AS (
      SELECT p.sub_distributorid, om.catgroupid, count(DISTINCT(r.outletid)) totalOulet, sum(rd.displaycost) displaycostTotal, sum(rd.locationcost) locationcostTotal
      FROM fcvplatform.psoutlet p
        INNER JOIN fcvplatform.psoutletmonthlyregister_bk_final r ON p.outletid = r.outletid
        INNER JOIN fcvplatform.psoutletmonthlyregisterdetail_bk_final rd ON r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
        INNER JOIN fcvplatform.outletmodel om ON rd.outletmodelid = om.outletmodelid
      where r.month = monthVar and r.year = yearVar and r.status = statusDefault and  p.sub_distributorid = ANY (distributorIdVar)
      GROUP BY p.sub_distributorid, om.catgroupid
  )
  INSERT INTO fcvplatform.psbudgettargetsdistributorcatgroupdetail (psbudgettargetsdistributorid, catgroupid, totaloutlet, displaycost, locationcost)
    SELECT td.psbudgettargetsdistributorid, ro.catgroupid, sum(ro.totalOulet), sum(ro.displaycostTotal), sum(ro.locationcostTotal)
    FROM fcvplatform.psbudgettargetsdistributor td
      INNER JOIN psoutletRegisterTableTmp ro ON ro.sub_distributorid = td.distributorid
    WHERE td.month = monthNextVar AND td.year = yearNextVar
    GROUP BY td.psbudgettargetsdistributorid, ro.catgroupid;
END;
$$;
