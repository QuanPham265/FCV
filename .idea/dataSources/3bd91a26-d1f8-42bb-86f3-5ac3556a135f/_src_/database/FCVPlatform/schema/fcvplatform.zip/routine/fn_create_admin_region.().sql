create function fn_create_admin_region() returns integer
LANGUAGE plpgsql
AS $$
declare region_rc record;
declare u_usergroup record;
declare u_user_admin record;
BEGIN

    BEGIN
        select * into u_user_admin from fcvplatform.users where upper(username) = upper('admin') and status = 1 limit 1;
	select * into u_usergroup from fcvplatform.usergroup where code = 'RSM' limit 1;
	FOR region_rc IN (select * from fcvplatform.region where status = 0)
	LOOP
		BEGIN
			IF (select not exists (select 1 from fcvplatform.users where username = 'ad_' || regexp_replace(lower(region_rc.name),'[\s\n\r\t]+','') and status = 1)) THEN
			insert into fcvplatform.users (username, code, password, fullname, firstname, lastname, status, usergroupid, createddate, modifieddate)
			values ('ad_' || regexp_replace(lower(region_rc.name),'[\s\n\r\t]+',''), 'ad_' || regexp_replace(lower(region_rc.name),'[\s\n\r\t]+',''), u_user_admin.password, region_rc.name, region_rc.name, region_rc.name, 1, u_usergroup.usergroupid, now(), now());
			END IF;
		END;
	END LOOP;    
    END;
    return 1;
END;
$$;
