create function fn_refreshinvoicedetailview() returns void
LANGUAGE plpgsql
AS $$
BEGIN

    BEGIN
      IF cast((select count(*) from fcvplatform.mergecustomerlog  where status = 'NEW' and isRefreshInvoiceView = false) as integer) > 0 THEN
        refresh MATERIALIZED VIEW fcvplatform.vw_invoice_detail_copy;
        refresh MATERIALIZED VIEW fcvplatform.vw_invoice_copy;
        update fcvplatform.mergecustomerlog set isRefreshInvoiceView = true where status = 'NEW';
      END IF;
    END;
END;
$$;
