create function fn_findregistry_outletmodelgroup_m_m1(d_distributorid bigint[], month_m0 integer, year_m0 integer, status_m0 integer[], perfectcodelist text[]) returns TABLE(outletid bigint, o_code text, o_name text, sub_distributorid bigint, sd_code text, sd_name text, outletmodelgroupid bigint, new_outletmodelid bigint, old_outletmodelid bigint, new_locationcost bigint)
LANGUAGE plpgsql
AS $$
declare year_m1 integer;
  declare month_m1 integer;
BEGIN
  month_m1 = month_m0 - 1;
  year_m1 = year_m0;
  if (month_m0 = 1) then
    month_m1 = 12;
    year_m1 = year_m0 - 1;
  end if;

  RETURN QUERY
  WITH RS AS (
    with rg_old as (
        select  distinct on (r.outletid, rd.outletmodelgroupid)
          r.outletid,
          v.code o_code,
          v.name o_name,
          v.sub_distributorid,
          sd.code sd_code,
          sd.name sd_name,
          rd.outletmodelgroupid,
          rd.outletmodelid
        from fcvplatform.psoutletmonthlyregistertemp  r
          inner join fcvplatform.psoutletmonthlyregisterdetailtemp rd
            on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
          inner join fcvplatform.psoutletmodelsetting  st
            on st.outletmodelid = rd.outletmodelid
          inner join fcvplatform.psoutlet v on r.outletid = v.outletid
          inner join fcvplatform.subdistributor sd on sd.distributorid = v.sub_distributorid
          inner join fcvplatform.outletmodelgroup omg
            on omg.outletmodelgroupid = rd.outletmodelgroupid
        where r.month = month_m1 and r.year = year_m1 and r.status = 100
              and omg.perfectcode = ANY (perfectCodeList)
              and v.sub_distributorid = ANY (d_distributorid)
    )
    select  rg_new.outletid,
      cast(rg_new.o_code as text) ,
      cast(rg_new.o_name as text) ,
      rg_new.sub_distributorid,
      cast(rg_new.sd_code as text) ,
      cast(rg_new.sd_name as text) ,
      rg_new.outletmodelgroupid,
      rg_new.outletmodelid new_outletmodelid,
      rg_old.outletmodelid old_outletmodelid,
      rg_new.displaylocationid
    from (
           select distinct on (r.outletid, rd.outletmodelgroupid)
             r.outletid,
             v.code o_code,
             v.name o_name,
             v.sub_distributorid,
             sd.code sd_code,
             sd.name sd_name,
             rd.outletmodelgroupid,
             rd.outletmodelid,
             rd.displaylocationid
           from fcvplatform.psoutletmonthlyregistertemp  r
             inner join fcvplatform.psoutletmonthlyregisterdetailtemp rd
               on r.psoutletmonthlyregisterid = rd.psoutletmonthlyregisterid
             inner join fcvplatform.psoutletmodelsetting  st
               on st.outletmodelid = rd.outletmodelid
             inner join fcvplatform.psoutlet v on r.outletid = v.outletid
             inner join fcvplatform.subdistributor sd on sd.distributorid = v.sub_distributorid
             inner join fcvplatform.outletmodelgroup omg
               on omg.outletmodelgroupid = rd.outletmodelgroupid
             inner join fcvplatform.outletmodel om on om.outletmodelid = rd.outletmodelid
           where r.month = month_m0 and r.year = year_m0  and (-1 = ANY (status_m0) or r.status = ANY (status_m0))
                 and omg.perfectcode = ANY (perfectCodeList)
                 and v.sub_distributorid = ANY (d_distributorid)
         ) rg_new
      left join rg_old on rg_old.outletid = rg_new.outletid and rg_old.outletmodelgroupid = rg_new.outletmodelgroupid
  )
  select * from rs;

END;
$$;
