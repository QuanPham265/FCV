create function fn_mergedmsdetail() returns void
LANGUAGE plpgsql
AS $$
DECLARE   rec            RECORD;
  DECLARE rec1           RECORD;
  DECLARE dmsOutletIdNew BIGINT;
  DECLARE dmsInvoiceIdNew BIGINT;
  DECLARE current_id     INTEGER;

BEGIN
  FOR rec IN
  SELECT DISTINCT
    dmso.code,
    dmso.dmsoutletid AS dmsoutletid, substring(dmso.code, 7, 15) as shortcode
  FROM FCVPlatform.dmsoutlet dmso, FCVPlatform.mergecustomerlog mc 
  WHERE dmso.statusmerge = TRUE AND mc.customeroldcode = dmso.code AND mc.createddate >= DATE('2018-03-31') AND
                         mc.status = 'COMPLETED'
  AND EXISTS(SELECT 1 FROM FCVPlatform.dmsinvoice dmsi WHERE dmsi.dmsoutletid = dmso.dmsoutletid
  AND (dmsi.statusmerge IS NULL OR dmsi.statusmerge = FALSE)
        AND dmsi.issueddate >= DATE('2017-01-01'))
		
  LOOP
    BEGIN
--       get newOutletId
      SELECT dmsoutletid
      INTO dmsOutletIdNew
      FROM FCVPlatform.dmsOutlet
      WHERE (statusMerge IS NULL OR statusMerge = FALSE) AND code LIKE '%' || rec.shortcode;

--     loop update and clone dmsinvoice and update dmsinvoiceid by newId
      FOR rec1 IN
      SELECT invoiceId
      FROM FCVPlatform.dmsinvoice
      WHERE dmsoutletid = rec.dmsoutletid AND (dmsinvoice.statusmerge = FALSE OR dmsinvoice.statusmerge IS NULL)
      LOOP
        BEGIN
--           update status merge for dmsinvoice
          UPDATE FCVPlatform.dmsinvoice
          SET statusmerge = TRUE
          WHERE invoiceId = rec1.invoiceId;
--           clone dmsinvoice
          INSERT INTO FCVPlatform.dmsinvoice (dmsoutletid, issueddate, invoicecode, totalcost, createddate, prioritycode, description, discountamount, totaltax, statecode,
                                  statuscode, versionnumber, idhashcode, invoiceno, statusmerge, orderno, mergefromid, mergedate, statusread, mergetoid, backuptotalcost)
            Select dmsOutletIdNew,issueddate,invoicecode, totalcost,createddate,prioritycode,description,discountamount,totaltax,statecode,
              statuscode,versionnumber,idhashcode,invoiceno,FALSE,orderno,rec1.invoiceId, now() , statusread ,NULL ,backuptotalcost
            from FCVPlatform.dmsinvoice WHERE invoiceid = rec1.invoiceId;
--           get dmsInvoiceId New
          SELECT currval('dmsinvoice_invoiceid_seq') INTO dmsInvoiceIdNew;
--           update dmsInvoiceDetail follow by newDmsInvoiceId
          update FCVPlatform.dmsinvoicedetail set invoiceid =  dmsInvoiceIdNew WHERE invoiceid = rec1.invoiceid;
        END;
      END LOOP;

    END;
  END LOOP;
END;
$$;
