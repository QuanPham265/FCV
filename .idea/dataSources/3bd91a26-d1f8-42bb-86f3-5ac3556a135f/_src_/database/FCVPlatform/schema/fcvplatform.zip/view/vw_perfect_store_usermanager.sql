CREATE VIEW vw_perfect_store_usermanager AS WITH nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid AS (
         WITH nnwid_rsmid_regionid_asmid_cityid_seid_disid AS (
                 WITH nnwid_rsmid_regionid_asmid_cityid_seid AS (
                         WITH nnwid_rsmid_regionid_asmid_cityid AS (
                                 WITH nnwid_rsmid_regionid_asmid AS (
 WITH nnwid_rsmid_regionid AS (
   WITH nnwid_rsmid AS (
     WITH rsmid AS (
       SELECT DISTINCT ON (lm_7.userid) lm_7.userid AS rsmid,
          u_2.username AS rsm_username,
          u_2.fullname AS rsm_fullname
         FROM (fcvplatform.linemanager lm_7
           JOIN fcvplatform.users u_2 ON ((u_2.userid = lm_7.userid)))
        WHERE (lm_7.regionid IS NOT NULL)
      )
     SELECT DISTINCT ON (rsmid.rsmid) lm_6.userid AS nnwid,
        u_1.username AS nnw_username,
        u_1.fullname AS nnw_fullname,
        rsmid.rsmid,
        rsmid.rsm_username,
        rsmid.rsm_fullname
       FROM ((fcvplatform.linemanager lm_6
         JOIN rsmid ON ((rsmid.rsmid = lm_6.staffuserid)))
         JOIN fcvplatform.users u_1 ON ((u_1.userid = lm_6.userid)))
    )
   SELECT nnwid_rsmid.nnwid,
      nnwid_rsmid.nnw_username,
      nnwid_rsmid.nnw_fullname,
      nnwid_rsmid.rsmid,
      nnwid_rsmid.rsm_username,
      nnwid_rsmid.rsm_fullname,
      lm_5.regionid,
      r.name AS regionname
     FROM ((fcvplatform.linemanager lm_5
       JOIN nnwid_rsmid ON ((nnwid_rsmid.rsmid = lm_5.userid)))
       JOIN fcvplatform.region r ON ((r.regionid = lm_5.regionid)))
    WHERE (lm_5.regionid IS NOT NULL)
  )
 SELECT DISTINCT ON (nnwid_rsmid_regionid.nnwid, nnwid_rsmid_regionid.regionid, lm_4.staffuserid) nnwid_rsmid_regionid.nnwid,
    nnwid_rsmid_regionid.nnw_username,
    nnwid_rsmid_regionid.nnw_fullname,
    nnwid_rsmid_regionid.rsmid,
    nnwid_rsmid_regionid.rsm_username,
    nnwid_rsmid_regionid.rsm_fullname,
    nnwid_rsmid_regionid.regionid,
    nnwid_rsmid_regionid.regionname,
    lm_4.staffuserid AS asmid,
    lm_4.username AS asm_username,
    lm_4.fullname AS asm_fullname
   FROM (nnwid_rsmid_regionid
     LEFT JOIN ( SELECT lm_5.userid,
      lm_5.staffuserid,
      u_1.username,
      u_1.fullname,
      dis.regionid
     FROM (((fcvplatform.linemanager lm_5
       JOIN fcvplatform.linemanager lm1 ON ((lm1.userid = lm_5.staffuserid)))
       JOIN fcvplatform.distributor dis ON ((dis.cityid = lm1.cityid)))
       JOIN fcvplatform.users u_1 ON ((u_1.userid = lm_5.staffuserid)))) lm_4 ON (((nnwid_rsmid_regionid.rsmid = lm_4.userid) AND (lm_4.regionid = nnwid_rsmid_regionid.regionid))))
)
                                 SELECT nnwid_rsmid_regionid_asmid.nnwid,
                                    nnwid_rsmid_regionid_asmid.nnw_username,
                                    nnwid_rsmid_regionid_asmid.nnw_fullname,
                                    nnwid_rsmid_regionid_asmid.rsmid,
                                    nnwid_rsmid_regionid_asmid.rsm_username,
                                    nnwid_rsmid_regionid_asmid.rsm_fullname,
                                    nnwid_rsmid_regionid_asmid.regionid,
                                    nnwid_rsmid_regionid_asmid.regionname,
                                    nnwid_rsmid_regionid_asmid.asmid,
                                    nnwid_rsmid_regionid_asmid.asm_username,
                                    nnwid_rsmid_regionid_asmid.asm_fullname,
                                    lm_3.cityid,
                                    c.name AS cityname
                                   FROM ((fcvplatform.linemanager lm_3
                                     JOIN nnwid_rsmid_regionid_asmid ON ((nnwid_rsmid_regionid_asmid.asmid = lm_3.userid)))
                                     JOIN fcvplatform.city c ON ((c.cityid = lm_3.cityid)))
                                  WHERE ((lm_3.cityid IS NOT NULL) AND (EXISTS ( SELECT 1
   FROM fcvplatform.distributor dis
  WHERE ((dis.cityid = lm_3.cityid) AND (dis.regionid = nnwid_rsmid_regionid_asmid.regionid)))))
                                )
                         SELECT nnwid_rsmid_regionid_asmid_cityid.nnwid,
                            nnwid_rsmid_regionid_asmid_cityid.nnw_username,
                            nnwid_rsmid_regionid_asmid_cityid.nnw_fullname,
                            nnwid_rsmid_regionid_asmid_cityid.rsmid,
                            nnwid_rsmid_regionid_asmid_cityid.rsm_username,
                            nnwid_rsmid_regionid_asmid_cityid.rsm_fullname,
                            nnwid_rsmid_regionid_asmid_cityid.regionid,
                            nnwid_rsmid_regionid_asmid_cityid.regionname,
                            nnwid_rsmid_regionid_asmid_cityid.asmid,
                            nnwid_rsmid_regionid_asmid_cityid.asm_username,
                            nnwid_rsmid_regionid_asmid_cityid.asm_fullname,
                            nnwid_rsmid_regionid_asmid_cityid.cityid,
                            nnwid_rsmid_regionid_asmid_cityid.cityname,
                            lm_2.staffuserid AS seid,
                            lm_2.username AS se_username,
                            lm_2.fullname AS se_fullname
                           FROM (nnwid_rsmid_regionid_asmid_cityid
                             LEFT JOIN ( SELECT lm_3.userid,
                                    lm_3.staffuserid,
                                    u_1.username,
                                    u_1.fullname,
                                    dis.cityid
                                   FROM (((fcvplatform.linemanager lm_3
                                     JOIN fcvplatform.linemanager lm1 ON ((lm1.userid = lm_3.staffuserid)))
                                     JOIN fcvplatform.distributor dis ON ((dis.distributorid = lm1.distributorid)))
                                     JOIN fcvplatform.users u_1 ON ((u_1.userid = lm_3.staffuserid)))) lm_2 ON (((nnwid_rsmid_regionid_asmid_cityid.asmid = lm_2.userid) AND (lm_2.cityid = nnwid_rsmid_regionid_asmid_cityid.cityid))))
                        )
                 SELECT nnwid_rsmid_regionid_asmid_cityid_seid.nnwid,
                    nnwid_rsmid_regionid_asmid_cityid_seid.nnw_username,
                    nnwid_rsmid_regionid_asmid_cityid_seid.nnw_fullname,
                    nnwid_rsmid_regionid_asmid_cityid_seid.rsmid,
                    nnwid_rsmid_regionid_asmid_cityid_seid.rsm_username,
                    nnwid_rsmid_regionid_asmid_cityid_seid.rsm_fullname,
                    nnwid_rsmid_regionid_asmid_cityid_seid.regionid,
                    nnwid_rsmid_regionid_asmid_cityid_seid.regionname,
                    nnwid_rsmid_regionid_asmid_cityid_seid.asmid,
                    nnwid_rsmid_regionid_asmid_cityid_seid.asm_username,
                    nnwid_rsmid_regionid_asmid_cityid_seid.asm_fullname,
                    nnwid_rsmid_regionid_asmid_cityid_seid.cityid,
                    nnwid_rsmid_regionid_asmid_cityid_seid.cityname,
                    nnwid_rsmid_regionid_asmid_cityid_seid.seid,
                    nnwid_rsmid_regionid_asmid_cityid_seid.se_username,
                    nnwid_rsmid_regionid_asmid_cityid_seid.se_fullname,
                    lm_1.distributorid,
                    d.code AS distributorcode,
                    d.name AS distributorname
                   FROM ((fcvplatform.linemanager lm_1
                     JOIN nnwid_rsmid_regionid_asmid_cityid_seid ON ((nnwid_rsmid_regionid_asmid_cityid_seid.seid = lm_1.userid)))
                     LEFT JOIN fcvplatform.distributor d ON (((d.distributorid = lm_1.distributorid) AND (d.cityid = nnwid_rsmid_regionid_asmid_cityid_seid.cityid))))
                  WHERE (lm_1.distributorid IS NOT NULL)
                )
         SELECT nnwid_rsmid_regionid_asmid_cityid_seid_disid.nnwid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.nnw_username,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.nnw_fullname,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.rsmid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.rsm_username,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.rsm_fullname,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.regionid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.regionname,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.asmid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.asm_username,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.asm_fullname,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.cityid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.cityname,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.seid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.se_username,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.se_fullname,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.distributorid,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.distributorcode,
            nnwid_rsmid_regionid_asmid_cityid_seid_disid.distributorname,
            lm.staffuserid AS smid,
            u.username AS sm_username,
            u.fullname AS sm_fullname
           FROM ((fcvplatform.linemanager lm
             JOIN nnwid_rsmid_regionid_asmid_cityid_seid_disid ON ((nnwid_rsmid_regionid_asmid_cityid_seid_disid.seid = lm.userid)))
             JOIN fcvplatform.users u ON ((u.userid = lm.staffuserid)))
          ORDER BY nnwid_rsmid_regionid_asmid_cityid_seid_disid.nnwid, nnwid_rsmid_regionid_asmid_cityid_seid_disid.rsmid, nnwid_rsmid_regionid_asmid_cityid_seid_disid.asmid, nnwid_rsmid_regionid_asmid_cityid_seid_disid.seid, lm.staffuserid
        )
 SELECT nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.nnwid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.nnw_username,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.nnw_fullname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.rsmid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.rsm_username,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.rsm_fullname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.regionid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.regionname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.asmid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.asm_username,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.asm_fullname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.cityid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.cityname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.seid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.se_username,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.se_fullname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.distributorid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.distributorcode,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.distributorname,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.smid,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.sm_username,
    nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid.sm_fullname
   FROM nnwid_rsmid_regionid_asmid_cityid_seid_disid_smid;
