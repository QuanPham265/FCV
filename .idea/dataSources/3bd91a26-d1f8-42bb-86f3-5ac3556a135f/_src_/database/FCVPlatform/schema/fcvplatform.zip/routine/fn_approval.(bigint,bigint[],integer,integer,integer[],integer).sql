create function fn_approval(userid bigint, d_distributorid bigint[], m_month integer, y_year integer, current_status integer[], next_status integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE   disId            BIGINT;
  DECLARE begin_rg_id      BIGINT;
  DECLARE begin_rg_temp_id BIGINT;
  DECLARE begin_partial_id BIGINT;
  DECLARE partial_rc       RECORD;
  DECLARE partial_id_flag  BIGINT;
BEGIN
  IF (next_status = ANY (current_status))
  THEN
    RETURN -1;
  END IF;
  --begin_rg_id = 10 + select nextval('fcvplatform.psoutletmonthlyregister_psoutletmonthlyregisterid_seq');
  --begin_rg_temp_id = 10 + select nextval('fcvplatform.psoutletmonthlyregistertemp_psoutletmonthlyregisterid_seq');
  FOR disId IN (SELECT distributorid
                FROM fcvplatform.subdistributor
                WHERE distributorid = ANY (d_distributorid))
  LOOP
    partial_id_flag = 0;
    FOR partial_rc IN
    WITH registry_need_update AS (
        SELECT
          r.outletid,
          r.month,
          r.year,
          r.status,
          r.createdby,
          r.createddate,
          r.modifiedby,
          r.modifieddate,
          r.actiontype,
          rd.*,
          mr.psoutletmonthlyregisterid  mr_id,
          mrt.psoutletmonthlyregisterid mrt_id
        FROM fcvplatform.psoutletmonthlyregisterpartial r
          INNER JOIN fcvplatform.psoutletmonthlyregisterdetailpartial rd
            ON r.psoutletmonthlyregisterpartialid = rd.psoutletmonthlyregisterpartialid
          INNER JOIN fcvplatform.psoutlet p ON p.outletid = r.outletid
          LEFT JOIN fcvplatform.psoutletmonthlyregister mr
            ON (mr.outletid = r.outletid AND mr.month = r.month AND mr.year = r.year)
          LEFT JOIN fcvplatform.psoutletmonthlyregistertemp mrt
            ON (mrt.outletid = r.outletid AND mrt.month = r.month AND mrt.year = r.year)
        WHERE r.month = m_month AND r.year = y_year AND r.status = ANY (current_status)
              AND p.sub_distributorid = disId
    )
    SELECT *
    FROM registry_need_update u
    LOOP
      IF (next_status = 1001)
      THEN
        IF (partial_id_flag != partial_rc.psoutletmonthlyregisterpartialid)
        THEN
          partial_id_flag = partial_rc.psoutletmonthlyregisterpartialid;
          IF (partial_rc.actiontype = 1000 OR partial_rc.actiontype = 1001)
          THEN
            IF (partial_rc.mr_id IS NULL)
            THEN
              SELECT nextval('fcvplatform.psoutletmonthlyregister_psoutletmonthlyregisterid_seq')
              INTO begin_rg_id;
              INSERT INTO fcvplatform.psoutletmonthlyregister
              (
                psoutletmonthlyregisterid,
                outletid,
                month,
                year,
                status,
                createdby,
                createddate,
                modifiedby,
                modifieddate
                --partialplan,
                --partialstatus,
                --reject_note,
                --approval_note
              )
              VALUES
                (
                  begin_rg_id,
                  partial_rc.outletid,
                  partial_rc.month,
                  partial_rc.year,
                  100,
                  partial_rc.createdby,
                  partial_rc.createddate,
                  partial_rc.modifiedby,
                  partial_rc.modifieddate
                  --partial_rc.partialplan,
                  --partial_rc.partialstatus,
                  --partial_rc.reject_note,
                  --partial_rc.approval_note
                );
            ELSE begin_rg_id = partial_rc.mr_id;
            END IF;
            IF (partial_rc.mrt_id IS NULL)
            THEN
              SELECT nextval('fcvplatform.psoutletmonthlyregistertemp_psoutletmonthlyregisterid_seq')
              INTO begin_rg_temp_id;
              INSERT INTO fcvplatform.psoutletmonthlyregistertemp
              (
                psoutletmonthlyregisterid,
                outletid,
                month,
                year,
                status,
                createdby,
                createddate,
                modifiedby,
                modifieddate
                --typeplan,
                --partialplan,
                --partialstatus,
                --reject_note,
                --approval_note
              )
              VALUES
                (
                  begin_rg_temp_id,
                  partial_rc.outletid,
                  partial_rc.month,
                  partial_rc.year,
                  100,
                  partial_rc.createdby,
                  partial_rc.createddate,
                  partial_rc.modifiedby,
                  partial_rc.modifieddate
                  --partial_rc.typeplan,
                  --partial_rc.partialplan,
                  --partial_rc.partialstatus,
                  --partial_rc.reject_note,
                  --partial_rc.approval_note
                );
            ELSE begin_rg_temp_id = partial_rc.mrt_id;
            END IF;
          END IF;
        END IF;
        IF (partial_rc.actiontype = 1000 OR partial_rc.actiontype = 1001)
        THEN
          INSERT INTO fcvplatform.psoutletmonthlyregisterdetail
          (
            psoutletmonthlyregisterid,
            psoutletmodelsettingid,
            expectcutoff,
            commitcutoff,
            commitnote,
            displaycost,
            displaylocationid,
            locationcost,
            outletmodelgroupid,
            outletmodelid,
            --outletmodeloldid,
            locationnote,
            model_note,
            --partialplan,
            --partialstatus,
            cashier
          )
          VALUES
            (
              begin_rg_id,
              partial_rc.psoutletmodelsettingid,
              partial_rc.expectcutoff,
              partial_rc.commitcutoff,
              partial_rc.commitnote,
              partial_rc.displaycost,
              partial_rc.displaylocationid,
              partial_rc.locationcost,
              partial_rc.outletmodelgroupid,
              partial_rc.outletmodelid,
              --partial_rc.outletmodeloldid,
              partial_rc.locationnote,
              partial_rc.model_note,
              --partial_rc.partialplan,
              --partial_rc.partialstatus,
              partial_rc.cashier
            );
          INSERT INTO fcvplatform.psoutletmonthlyregisterdetailtemp
          (
            psoutletmonthlyregisterid,
            psoutletmodelsettingid,
            expectcutoff,
            commitcutoff,
            commitnote,
            displaycost,
            displaylocationid,
            locationcost,
            outletmodelgroupid,
            outletmodelid,
            --outletmodeloldid,
            locationnote,
            model_note,
            --partialplan,
            --partialstatus,
            cashier
          )
          VALUES
            (
              begin_rg_temp_id,
              partial_rc.psoutletmodelsettingid,
              partial_rc.expectcutoff,
              partial_rc.commitcutoff,
              partial_rc.commitnote,
              partial_rc.displaycost,
              partial_rc.displaylocationid,
              partial_rc.locationcost,
              partial_rc.outletmodelgroupid,
              partial_rc.outletmodelid,
              --partial_rc.outletmodeloldid,
              partial_rc.locationnote,
              partial_rc.model_note,
              --partial_rc.partialplan,
              --partial_rc.partialstatus,
              partial_rc.cashier
            );
        ELSE
          DELETE FROM fcvplatform.psoutletmonthlyregisterdetailtemp
          WHERE psoutletmonthlyregisterid = partial_rc.mrt_id
                AND outletmodelgroupid = partial_rc.outletmodelgroupid;

          DELETE FROM fcvplatform.psoutletmonthlyregisterdetail
          WHERE psoutletmonthlyregisterid = partial_rc.mr_id
                AND outletmodelgroupid = partial_rc.outletmodelgroupid;
        END IF;
      END IF;
      UPDATE fcvplatform.psoutletmonthlyregisterpartial r
      SET status = next_status
      WHERE r.psoutletmonthlyregisterpartialid = partial_rc.psoutletmonthlyregisterpartialid;
    END LOOP;
  END LOOP;
  IF (100 = ANY (current_status))
  THEN
    RETURN 100;
  END IF;
  RETURN 1;
END;
$$;
