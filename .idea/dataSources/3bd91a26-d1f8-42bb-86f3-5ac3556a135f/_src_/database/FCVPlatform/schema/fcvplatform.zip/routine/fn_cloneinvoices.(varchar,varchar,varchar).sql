create function fn_cloneinvoices(fromcode character varying, tocode character varying, fromdate character varying) returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
  DECLARE details Record;
  DECLARE newInvoiceId BIGINT;
  DECLARE toOutletId BIGINT;
BEGIN
  select dmsoutletid from dmsoutlet WHERE code = toCode INTO toOutletId;
  FOR rec IN
  select * from dmsinvoice
  WHERE
    dmsoutletid = (select dmsoutletid from dmsoutlet WHERE code = fromCode)
    and date(issueddate) >= date(fromDate)
  LOOP
    BEGIN
      Update dmsinvoice set statusmerge = true where invoiceid = rec.invoiceid;
      SELECT nextval('dmsinvoice_invoiceid_seq') INTO newInvoiceId;

      INSERT INTO dmsinvoice (invoiceid,dmsoutletid,issueddate,invoicecode,totalcost,createddate,prioritycode,description,discountamount,
                              totaltax,statecode,statuscode,versionnumber,invoiceno,orderno)
      VALUES (newInvoiceId, toOutletId,rec.issueddate,rec.invoicecode,rec.totalcost,rec.createddate,rec.prioritycode,rec.description,rec.discountamount,
                            rec.totaltax,rec.statecode,rec.statuscode,rec.versionnumber,rec.invoiceno,rec.orderno);

      FOR details IN SELECT * from dmsinvoicedetail
      WHERE invoiceid = rec.invoiceid
      LOOP
        BEGIN
          INSERT INTO dmsinvoicedetail (invoiceid,productid,quantity,costperunit,cost,extendedamount,tax,exchangerate,
                                        description,versionnumber,createddate,doc_type,cust_city,cust_province,geography,channel,outlet,key_acc,key_acc_region,prd_desc
            ,mg1,mg2,mg3,mg4,prd_content,uom_cd,uom_listprice,promo_disc,net_amt,slsman_cd,slsman_name,reason_code,remark,inv_key,so_no,so_key,whs_cd,inv_ind,bill_to_cd
            ,cust_type,so_dt,created_by,delivery_dt,invterm_cd,inv_status,gross_ttl,net_ttl,net_ttl_tax,adj_amt,taxable_amt,nontaxable_amt,invoice_due_dt,gps_latitude,gps_longitude)
          VALUES (newInvoiceId,details.productid,details.quantity,details.costperunit,details.cost,details.extendedamount,details.tax,details.exchangerate,
                               details.description,details.versionnumber,details.createddate,details.doc_type,details.cust_city,details.cust_province,details.geography,details.channel,details.outlet,details.key_acc,details.key_acc_region,details.prd_desc
            ,details.mg1,details.mg2,details.mg3,details.mg4,details.prd_content,details.uom_cd,details.uom_listprice,details.promo_disc,details.net_amt,details.slsman_cd,details.slsman_name,details.reason_code,details.remark,details.inv_key,details.so_no,details.so_key,details.whs_cd,details.inv_ind,details.bill_to_cd
            ,details.cust_type,details.so_dt,details.created_by,details.delivery_dt,details.invterm_cd,details.inv_status,details.gross_ttl,details.net_ttl,details.net_ttl_tax,details.adj_amt,details.taxable_amt,details.nontaxable_amt,details.invoice_due_dt,details.gps_latitude,details.gps_longitude);
        END;
      END LOOP;

    END;
  END LOOP;
END;
$$;
