create function fn_inserttocumulactiveapp() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec RECORD;
BEGIN
  FOR rec IN
  SELECT cumulativetransactionid,transactiontype, transactiontime, status, customerid, earnedpoint, invoiceamount, bonuspointforrank, bonuspointnotforrank, campaignid, invoicenumber, cyclerankingid, redemptionpoint, createddate, statecode, mergefromid, mergedate
  FROM cumulativetransaction
  WHERE customerid = 918627
  LOOP
    BEGIN
      INSERT INTO cumulativetransaction (transactiontype, transactiontime, status, customerid, earnedpoint, invoiceamount, bonuspointforrank, bonuspointnotforrank, campaignid, invoicenumber, cyclerankingid, redemptionpoint, createddate, statecode, mergefromid, mergedate
) VALUES (
        rec.transactiontype, rec.transactiontime, rec.status, 918736, rec.earnedpoint, rec.invoiceamount, rec.bonuspointforrank, rec.bonuspointnotforrank, rec.campaignid, rec.invoicenumber, rec.cyclerankingid, rec.redemptionpoint, rec.createddate, rec.statecode, rec.cumulativetransactionid, now()

      );

    END;
  END LOOP;
END;
$$;
