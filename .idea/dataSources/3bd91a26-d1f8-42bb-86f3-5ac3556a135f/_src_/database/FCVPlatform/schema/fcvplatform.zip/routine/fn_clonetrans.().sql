create function fn_clonetrans() returns void
LANGUAGE plpgsql
AS $$
DECLARE rec Record;
BEGIN
  FOR rec IN SELECT * FROM cumulativetransaction WHERE customerid = 278938 LOOP
    BEGIN
      INSERT INTO cumulativetransaction (transactiontype,transactiontime,status,customerid,earnedpoint,invoiceamount,bonuspointforrank,bonuspointnotforrank,campaignid,invoicenumber,cyclerankingid,redemptionpoint,
                                         createddate,statecode)
      VALUES (rec.transactiontype,rec.transactiontime,rec.status,341176,rec.earnedpoint,rec.invoiceamount,rec.bonuspointforrank,rec.bonuspointnotforrank,
                                  rec.campaignid,cast(rec.invoicenumber || '_TEST' as TEXT),rec.cyclerankingid,rec.redemptionpoint,rec.createddate,rec.statecode
      );
    END;
  END LOOP;
END;
$$;
